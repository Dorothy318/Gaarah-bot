import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Upload, Download, FolderOpen } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function QRScanScreen() {
  const navigate = useNavigate();

  return (
    <div className="p-5 min-h-screen bg-card">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="text-muted-foreground">
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-lg font-bold font-heading">Interface PC</h1>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center"
      >
        <p className="text-sm text-muted-foreground mb-6">
          Aperçu de l'interface web accessible depuis le navigateur du PC
        </p>

        {/* Mock browser frame */}
        <div className="rounded-2xl border border-border overflow-hidden shadow-lg">
          {/* Browser bar */}
          <div className="bg-secondary px-3 py-2 flex items-center gap-2">
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-destructive/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-connect/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-receive/60" />
            </div>
            <div className="flex-1 bg-background rounded-md px-3 py-1 text-xs text-muted-foreground font-mono">
              192.168.43.1:8080
            </div>
          </div>

          {/* Web content */}
          <div className="bg-background p-6">
            <h2 className="text-xl font-bold font-heading text-primary mb-1">
              📡 ShareDrop
            </h2>
            <p className="text-xs text-muted-foreground mb-6">
              Connecté à "Mon Téléphone"
            </p>

            <div className="space-y-3">
              <motion.div
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-3 p-4 rounded-xl bg-primary/5 border border-primary/20 cursor-pointer"
              >
                <Upload size={20} className="text-primary" />
                <div className="text-left">
                  <p className="text-sm font-medium">Envoyer vers téléphone</p>
                  <p className="text-xs text-muted-foreground">
                    Glissez ou sélectionnez des fichiers
                  </p>
                </div>
              </motion.div>

              <motion.div
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-3 p-4 rounded-xl bg-receive/5 border border-receive/20 cursor-pointer"
              >
                <Download size={20} className="text-receive" />
                <div className="text-left">
                  <p className="text-sm font-medium">Télécharger depuis téléphone</p>
                  <p className="text-xs text-muted-foreground">
                    Parcourir les fichiers du téléphone
                  </p>
                </div>
              </motion.div>

              <motion.div
                whileTap={{ scale: 0.97 }}
                className="flex items-center gap-3 p-4 rounded-xl bg-secondary border border-border cursor-pointer"
              >
                <FolderOpen size={20} className="text-muted-foreground" />
                <div className="text-left">
                  <p className="text-sm font-medium">Explorateur de fichiers</p>
                  <p className="text-xs text-muted-foreground">
                    Naviguer dans le stockage
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </motion.div>

      <Button
        variant="outline"
        className="w-full mt-6 rounded-xl"
        onClick={() => navigate("/connect")}
      >
        Retour à la connexion
      </Button>
    </div>
  );
}
