import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import {
  Smartphone, FolderOpen, Moon, Shield, Info, Pencil,
  User, LogIn, LogOut, Globe, Bell,
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { SUPPORTED_LANGS, type LangCode } from "@/lib/i18n";
import {
  notificationsSupported, notificationsEnabled,
  requestNotifications, disableNotifications,
} from "@/lib/notifications";

const STORAGE_KEYS = {
  dark: "sharedrop_dark",
  deviceName: "sharedrop_device_name",
  autoAccept: "sharedrop_auto_accept",
} as const;

function applyDark(enabled: boolean) {
  document.documentElement.classList.toggle("dark", enabled);
}

export default function SettingsScreen() {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();
  const { user, signOut } = useAuth();

  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.dark);
    if (saved !== null) return saved === "true";
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? true;
  });
  const [autoAccept, setAutoAccept] = useState(
    () => localStorage.getItem(STORAGE_KEYS.autoAccept) === "true",
  );
  const [deviceName, setDeviceName] = useState(
    () => localStorage.getItem(STORAGE_KEYS.deviceName) ?? "Mon Téléphone",
  );
  const [editingName, setEditingName] = useState(false);
  const [draftName, setDraftName] = useState(deviceName);
  const [notifOn, setNotifOn] = useState(() => notificationsEnabled());

  useEffect(() => {
    applyDark(darkMode);
  }, [darkMode]);

  const toggleDark = (next: boolean) => {
    setDarkMode(next);
    localStorage.setItem(STORAGE_KEYS.dark, String(next));
  };

  const toggleAutoAccept = (next: boolean) => {
    setAutoAccept(next);
    localStorage.setItem(STORAGE_KEYS.autoAccept, String(next));
  };

  const toggleNotif = async (next: boolean) => {
    if (next) {
      const granted = await requestNotifications();
      setNotifOn(granted);
      if (granted) toast.success(t("settings.notificationsEnabled"));
      else toast.error(t("settings.notificationsDenied"));
    } else {
      disableNotifications();
      setNotifOn(false);
    }
  };

  const saveName = () => {
    const trimmed = draftName.trim().slice(0, 32);
    if (!trimmed) {
      toast.error(t("settings.nameEmpty"));
      return;
    }
    setDeviceName(trimmed);
    localStorage.setItem(STORAGE_KEYS.deviceName, trimmed);
    setEditingName(false);
    toast.success(t("settings.nameUpdated"));
  };

  const changeLang = (code: string) => {
    void i18n.changeLanguage(code as LangCode);
  };

  const handleSignOut = async () => {
    await signOut();
    toast.success(t("auth.signOutSuccess"));
  };

  return (
    <div className="p-5">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold font-heading">{t("settings.title")}</h1>
      </motion.div>

      {/* Account section */}
      <div className="mt-6 space-y-2">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-1">
          {t("settings.account")}
        </span>
        {user ? (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-card">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <User size={18} className="text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.email}</p>
              <p className="text-xs text-muted-foreground">{t("settings.signedInAs")}</p>
            </div>
            <Button size="sm" variant="ghost" onClick={handleSignOut} aria-label={t("common.signOut")}>
              <LogOut size={16} />
            </Button>
          </div>
        ) : (
          <button
            onClick={() => navigate("/auth")}
            className="w-full flex items-center gap-3 p-4 rounded-xl bg-card hover:bg-card/70 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <LogIn size={18} className="text-primary" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">{t("common.signIn")}</p>
              <p className="text-xs text-muted-foreground">{t("settings.notSignedIn")}</p>
            </div>
          </button>
        )}
      </div>

      {/* Preferences */}
      <div className="mt-6 space-y-2">
        <div className="flex items-center gap-3 p-4 rounded-xl bg-card">
          <Smartphone size={20} className="text-primary" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium">{t("settings.deviceName")}</p>
            {editingName ? (
              <div className="flex gap-2 mt-2">
                <Input
                  value={draftName}
                  onChange={(e) => setDraftName(e.target.value)}
                  maxLength={32}
                  autoFocus
                  className="h-8"
                />
                <Button size="sm" onClick={saveName}>{t("common.ok")}</Button>
              </div>
            ) : (
              <p className="text-xs text-muted-foreground truncate">{deviceName}</p>
            )}
          </div>
          {!editingName && (
            <button
              onClick={() => { setDraftName(deviceName); setEditingName(true); }}
              className="text-muted-foreground hover:text-primary transition-colors"
              aria-label={t("common.edit")}
            >
              <Pencil size={16} />
            </button>
          )}
        </div>

        <div className="flex items-center gap-3 p-4 rounded-xl bg-card">
          <Globe size={20} className="text-primary" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium">{t("settings.language")}</p>
          </div>
          <Select value={i18n.resolvedLanguage ?? "fr"} onValueChange={changeLang}>
            <SelectTrigger className="w-32 h-8 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {SUPPORTED_LANGS.map((l) => (
                <SelectItem key={l.code} value={l.code} className="text-xs">
                  {l.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-3 p-4 rounded-xl bg-card">
          <FolderOpen size={20} className="text-primary" />
          <div className="flex-1">
            <p className="text-sm font-medium">{t("settings.receiveFolder")}</p>
            <p className="text-xs text-muted-foreground">/Download/ShareDrop</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-4 rounded-xl bg-card">
          <Moon size={20} className="text-primary" />
          <div className="flex-1">
            <p className="text-sm font-medium">{t("settings.darkMode")}</p>
          </div>
          <Switch checked={darkMode} onCheckedChange={toggleDark} />
        </div>

        {notificationsSupported() && (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-card">
            <Bell size={20} className="text-primary" />
            <div className="flex-1">
              <p className="text-sm font-medium">{t("settings.notifications")}</p>
              <p className="text-xs text-muted-foreground">{t("settings.notificationsHint")}</p>
            </div>
            <Switch checked={notifOn} onCheckedChange={toggleNotif} />
          </div>
        )}

        <div className="flex items-center gap-3 p-4 rounded-xl bg-card">
          <Shield size={20} className="text-primary" />
          <div className="flex-1">
            <p className="text-sm font-medium">{t("settings.autoAccept")}</p>
            <p className="text-xs text-muted-foreground">{t("settings.autoAcceptHint")}</p>
          </div>
          <Switch checked={autoAccept} onCheckedChange={toggleAutoAccept} />
        </div>

        <div className="flex items-center gap-3 p-4 rounded-xl bg-card">
          <Info size={20} className="text-muted-foreground" />
          <div className="flex-1">
            <p className="text-sm font-medium">{t("settings.version")}</p>
            <p className="text-xs text-muted-foreground">ShareDrop v1.0.0 • MVP</p>
          </div>
        </div>
      </div>
    </div>
  );
}
