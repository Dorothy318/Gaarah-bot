import { useState, useCallback, useMemo, useEffect, useReducer } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { QrCode, Wifi, Bluetooth } from "lucide-react";
import { toast } from "sonner";

import QRScanner from "@/components/QRScanner";
import QRPanel from "@/components/connect/QRPanel";
import WifiPanel from "@/components/connect/WifiPanel";
import BluetoothPanel from "@/components/connect/BluetoothPanel";
import ConnectionHistoryPanel from "@/components/connect/ConnectionHistoryPanel";

import {
  generateRoomCode,
  generateRoomToken,
  encodeRoomInvite,
  decodeRoomInvite,
  hasTurnConfigured,
} from "@/lib/webrtc-signaling";
import { useTransferSession } from "@/contexts/TransferSession";
import {
  connectReducer,
  initialConnectStatus,
  describeConnectStatus,
  type ConnectMethod,
} from "@/lib/connect-machine";
import {
  loadHistory,
  saveHistoryEntry,
  clearHistoryStorage,
  getNetworkInfo,
  type DiscoveredDevice,
  type ConnectionHistoryEntry,
} from "@/lib/connect-types";

/** Demo device generator for the simulated Wi-Fi panel. */
function generateLocalDevices(): DiscoveredDevice[] {
  const netInfo = getNetworkInfo();
  const baseIp = "192.168.1.";
  const hostSuffix = Math.floor(Math.random() * 200) + 2;

  if (netInfo?.type === "wifi") {
    const devs: DiscoveredDevice[] = [
      { id: "local-1", name: `PC-${navigator.platform.split(" ")[0] || "Desktop"}`, type: "pc", signal: "Excellent", ip: `${baseIp}${hostSuffix}` },
    ];
    if (netInfo.downlink > 5) {
      devs.push({ id: "local-2", name: "Appareil réseau local", type: "phone", signal: "Bon", ip: `${baseIp}${hostSuffix + 1}` });
    }
    return devs;
  }
  return [
    { id: "w1", name: "PC-Bureau", type: "pc", signal: "Excellent", ip: `${baseIp}${hostSuffix}` },
    { id: "w2", name: "Tablette-Salon", type: "phone", signal: "Bon", ip: `${baseIp}${hostSuffix + 3}` },
  ];
}

const METHODS = [
  { id: "qr" as const, icon: QrCode, label: "QR Code", desc: "Scan rapide depuis un PC", color: "bg-primary/10 text-primary" },
  { id: "wifi" as const, icon: Wifi, label: "Wi-Fi Direct", desc: "Connexion haut débit", color: "bg-receive/10 text-receive" },
  { id: "bt" as const, icon: Bluetooth, label: "Bluetooth", desc: "Connexion de secours", color: "bg-connect/10 text-connect" },
];

export default function ConnectScreen() {
  const navigate = useNavigate();
  const [method, setMethod] = useState<ConnectMethod | null>(null);
  const [machineState, dispatch] = useReducer(connectReducer, initialConnectStatus);

  // Hardened WebRTC room (host-side QR invite)
  const room = useMemo(() => generateRoomCode(6), []);
  const token = useMemo(() => generateRoomToken(), []);
  const inviteUrl = useMemo(() => encodeRoomInvite(room, token), [room, token]);
  const [pin] = useState(() => Math.floor(1000 + Math.random() * 9000).toString());

  const session = useTransferSession();

  // Map session phase back to the PeerStatus shape QRPanel expects.
  const peerStatus = (session.phase === "connected" || session.phase === "transferring" || session.phase === "done")
    ? "connected"
    : session.phase === "connecting" ? "connecting"
    : session.phase === "waiting" ? "waiting"
    : session.phase === "joining" ? "joining"
    : session.phase === "failed" ? "failed"
    : session.phase === "disconnected" ? "disconnected"
    : "idle";

  // QR scanning state
  const [showScanner, setShowScanner] = useState(false);
  const [scannedResult, setScannedResult] = useState<string | null>(null);

  // Wi-Fi state
  const [wifiScanning, setWifiScanning] = useState(false);
  const [wifiDevices, setWifiDevices] = useState<DiscoveredDevice[]>([]);
  const [wifiConnected, setWifiConnected] = useState<string | null>(null);

  // Bluetooth state
  const [btScanning, setBtScanning] = useState(false);
  const [btDevices, setBtDevices] = useState<DiscoveredDevice[]>([]);
  const [btConnected, setBtConnected] = useState<string | null>(null);

  // History
  const [history, setHistory] = useState<ConnectionHistoryEntry[]>(loadHistory);
  const [reconnecting, setReconnecting] = useState<string | null>(null);

  // ── Side effects ────────────────────────────────────────────────────────

  // Surface WebRTC failures clearly
  useEffect(() => {
    if (session.phase === "failed") {
      toast.error("Connexion P2P échouée", {
        description: session.error ?? "Vérifiez le réseau ou réessayez (NAT strict ?)",
      });
      if (method) dispatch({ type: "FAIL", method, reason: session.error ?? "WebRTC" });
    } else if (session.phase === "connected" && method) {
      dispatch({ type: "CONNECTED", method });
    }
  }, [session.phase, session.error, method]);

  // Auto-host when QR panel is shown so guests can join immediately.
  useEffect(() => {
    if (method === "qr" && session.phase === "idle") {
      void session.startAsHost(room, token);
    }
  }, [method, session, room, token]);

  // ── Handlers ────────────────────────────────────────────────────────────

  const selectMethod = (id: ConnectMethod) => {
    setMethod(id);
    dispatch({ type: "SELECT_METHOD", method: id });
    if (id === "wifi" && wifiDevices.length === 0 && !wifiScanning) startWifiScan();
    if (id === "bt" && btDevices.length === 0 && !btScanning) startBtScan();
  };

  const startWifiScan = () => {
    setWifiScanning(true);
    setWifiDevices([]);
    setWifiConnected(null);
    dispatch({ type: "START_SCAN", method: "wifi" });
    toast.info("Scan du réseau local en cours...");

    const netInfo = getNetworkInfo();
    setTimeout(() => {
      setWifiDevices(generateLocalDevices().slice(0, 1));
      if (netInfo?.type === "wifi") toast.info(`Réseau Wi-Fi détecté (${netInfo.effectiveType})`);
    }, 1200);
    setTimeout(() => {
      const devs = generateLocalDevices();
      setWifiDevices(devs);
      setWifiScanning(false);
      dispatch({ type: "SCAN_RESULT", method: "wifi", count: devs.length });
      toast.success(`${devs.length} appareil(s) trouvé(s) sur le réseau`);
    }, 2800);
  };

  const startBtScan = () => {
    setBtScanning(true);
    setBtDevices([]);
    setBtConnected(null);
    dispatch({ type: "START_SCAN", method: "bt" });
    toast.info("Recherche Bluetooth en cours...");

    const finishWithDemo = () => {
      const demo: DiscoveredDevice[] = [
        { id: "b1", name: "iPhone 15 Pro", type: "phone", signal: "Fort" },
        { id: "b2", name: "Pixel 8", type: "phone", signal: "Faible" },
      ];
      setBtDevices(demo);
      setBtScanning(false);
      dispatch({ type: "SCAN_RESULT", method: "bt", count: demo.length });
      toast.success("2 appareils Bluetooth trouvés");
    };

    if ("bluetooth" in navigator) {
      (navigator as Navigator & { bluetooth: { requestDevice: (o: unknown) => Promise<{ id?: string; name?: string }> } })
        .bluetooth
        .requestDevice({ acceptAllDevices: true, optionalServices: ["battery_service"] })
        .then((device) => {
          const dev: DiscoveredDevice = {
            id: device.id || "real-1",
            name: device.name || "Appareil Bluetooth",
            type: "phone",
            signal: "Connecté",
          };
          setBtDevices([dev]);
          setBtScanning(false);
          dispatch({ type: "SCAN_RESULT", method: "bt", count: 1 });
          toast.success(`${dev.name} détecté`);
        })
        .catch(() => setTimeout(finishWithDemo, 1500));
    } else {
      setTimeout(finishWithDemo, 2000);
    }
  };

  const connectDevice = (device: DiscoveredDevice, type: "wifi" | "bt") => {
    dispatch({ type: "CONNECT_DEVICE", method: type, deviceId: device.id });
    if (type === "wifi") {
      setWifiConnected(device.id);
      toast.success(`Connecté à ${device.name} via Wi-Fi Direct`, {
        description: device.ip ? `IP: ${device.ip}` : undefined,
      });
    } else {
      setBtConnected(device.id);
      toast.success(`Connecté à ${device.name} via Bluetooth`);
    }
    dispatch({ type: "CONNECTED", method: type, deviceId: device.id });
    setHistory(saveHistoryEntry(device, type));
  };

  const reconnectDevice = async (entry: ConnectionHistoryEntry) => {
    setReconnecting(entry.id);
    toast.info(`Reconnexion à ${entry.name}...`);
    await new Promise((r) => setTimeout(r, 1500));
    const success = Math.random() > 0.15;

    if (success) {
      setMethod(entry.method);
      dispatch({ type: "SELECT_METHOD", method: entry.method });
      const device: DiscoveredDevice = {
        id: entry.id, name: entry.name, type: entry.type, signal: "Reconnecté", ip: entry.ip,
      };
      if (entry.method === "wifi") {
        setWifiDevices((prev) => prev.find((d) => d.name === entry.name) ? prev : [device, ...prev]);
        setWifiConnected(entry.id);
      } else if (entry.method === "bt") {
        setBtDevices((prev) => prev.find((d) => d.name === entry.name) ? prev : [device, ...prev]);
        setBtConnected(entry.id);
      } else {
        setScannedResult(entry.name);
      }
      dispatch({ type: "CONNECTED", method: entry.method, deviceId: entry.id });
      toast.success(`Reconnecté à ${entry.name} !`, {
        description: entry.ip ? `IP: ${entry.ip}` : `Via ${entry.method}`,
      });
      setHistory(saveHistoryEntry(device, entry.method));
    } else {
      dispatch({ type: "FAIL", method: entry.method, reason: "device unreachable" });
      toast.error(`Impossible de reconnecter à ${entry.name}`, {
        description: "L'appareil n'est peut-être plus sur le réseau",
      });
    }
    setReconnecting(null);
  };

  const handleQRScan = useCallback((data: string) => {
    setShowScanner(false);
    const invite = decodeRoomInvite(data);
    if (!invite) {
      toast.error("QR Code invalide", { description: "Format ShareDrop attendu" });
      return;
    }
    setScannedResult(`Salon ${invite.room}`);
    toast.success("Invitation détectée", { description: `Connexion au salon ${invite.room}…` });
    setHistory(saveHistoryEntry(
      { id: "qr", name: `Salon ${invite.room}`, type: "pc", signal: "", ip: invite.room },
      "qr",
    ));
    void session.startAsGuest(invite.room, invite.token);
    setTimeout(() => navigate("/transfer"), 400);
  }, [session, navigate]);

  const clearHistory = () => {
    clearHistoryStorage();
    setHistory([]);
    toast("Historique effacé");
  };

  // Live status text for screen readers
  const liveStatus = useMemo(() => {
    if (method === "qr") return `Statut QR : ${describeConnectStatus(machineState)}.`;
    if (method === "wifi") return wifiScanning
      ? "Scan Wi-Fi en cours."
      : `${wifiDevices.length} appareils Wi-Fi trouvés.`;
    if (method === "bt") return btScanning
      ? "Scan Bluetooth en cours."
      : `${btDevices.length} appareils Bluetooth trouvés.`;
    return "";
  }, [method, machineState, wifiScanning, wifiDevices.length, btScanning, btDevices.length]);

  // ── Render ──────────────────────────────────────────────────────────────

  return (
    <div className="p-5">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold font-heading">Connecter</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Reliez votre téléphone à un autre appareil
        </p>
      </motion.div>

      {/* Live status region for screen readers */}
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">
        {liveStatus}
      </div>

      {!hasTurnConfigured() && (
        <div className="mt-3 px-3 py-2 rounded-lg border border-amber-500/30 bg-amber-500/10 text-[11px] text-amber-600 dark:text-amber-400 flex items-center justify-between gap-2">
          <span>Mode STUN seul — possiblement bloqué derrière pare-feu.</span>
          <button
            type="button"
            onClick={() => navigate("/diagnostics")}
            className="shrink-0 underline font-medium"
          >
            Diagnostiquer
          </button>
        </div>
      )}

      <button
        type="button"
        onClick={() => navigate("/diagnostics")}
        className="mt-3 w-full text-xs text-muted-foreground hover:text-foreground underline-offset-2 hover:underline transition-colors"
      >
        Tester la connectivité réseau (STUN/TURN)
      </button>


      {/* Connection methods */}
      <div className="space-y-3 mt-6">
        {METHODS.map((m, i) => (
          <motion.div
            key={m.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            onClick={() => selectMethod(m.id)}
            className={`flex items-center gap-3 p-4 rounded-xl cursor-pointer transition-all ${
              method === m.id ? "bg-primary/10 ring-2 ring-primary/30" : "bg-card hover:bg-secondary"
            }`}
          >
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${m.color}`}>
              <m.icon size={20} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <p className="text-sm font-medium">{m.label}</p>
                {(m.id === "wifi" || m.id === "bt") && (
                  <span className="text-[9px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-500 border border-amber-500/30">
                    Démo
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground">{m.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {method === "qr" && (
          <QRPanel
            key="qr-panel"
            inviteUrl={inviteUrl}
            room={room}
            pin={pin}
            peerStatus={peerStatus}
            scannedResult={scannedResult}
            onRescan={() => setScannedResult(null)}
            onScannerOpen={() => setShowScanner(true)}
            onPCInterface={() => navigate("/qr-scan")}
            onSend={() => { toast.success("Connexion établie via QR !"); navigate("/send"); }}
          />
        )}
        {method === "wifi" && (
          <WifiPanel
            key="wifi-panel"
            scanning={wifiScanning}
            devices={wifiDevices}
            connectedId={wifiConnected}
            onRescan={startWifiScan}
            onConnect={(d) => connectDevice(d, "wifi")}
          />
        )}
        {method === "bt" && (
          <BluetoothPanel
            key="bt-panel"
            scanning={btScanning}
            devices={btDevices}
            connectedId={btConnected}
            onRescan={startBtScan}
            onConnect={(d) => connectDevice(d, "bt")}
          />
        )}
      </AnimatePresence>

      {!method && (
        <ConnectionHistoryPanel
          history={history}
          reconnectingId={reconnecting}
          onClear={clearHistory}
          onReconnect={reconnectDevice}
        />
      )}

      <AnimatePresence>
        {showScanner && (
          <QRScanner onScan={handleQRScan} onClose={() => setShowScanner(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}
