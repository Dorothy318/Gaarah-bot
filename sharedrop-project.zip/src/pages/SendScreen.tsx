import { useState, useRef, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Image, Video, FileText, Package, Plus, X, ArrowRight, File, Upload, Share2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { generateVideoThumbnail } from "@/lib/thumbnails";
import { useTransferSession } from "@/contexts/TransferSession";

interface SelectedFile {
  id: string;
  name: string;
  size: string;
  type: "image" | "video" | "document" | "apk" | "other";
  file?: File;
  thumbnail?: string;
}

const typeIcons = { image: Image, video: Video, document: FileText, apk: Package, other: File };
const typeColors: Record<string, string> = {
  image: "bg-primary/10 text-primary",
  video: "bg-accent/10 text-accent",
  document: "bg-connect/10 text-connect",
  apk: "bg-destructive/10 text-destructive",
  other: "bg-muted text-muted-foreground",
};

function formatSize(bytes: number): string {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + " GB";
}

function detectType(file: File): SelectedFile["type"] {
  const ext = file.name.split(".").pop()?.toLowerCase() || "";
  if (file.type.startsWith("image/") || ["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp"].includes(ext)) return "image";
  if (file.type.startsWith("video/") || ["mp4", "mkv", "avi", "mov", "webm"].includes(ext)) return "video";
  if (["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv"].includes(ext)) return "document";
  if (ext === "apk") return "apk";
  return "other";
}

const acceptMap: Record<string, string> = {
  image: "image/*",
  video: "video/*",
  document: ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv",
  apk: ".apk",
};

export default function SendScreen() {
  const [files, setFiles] = useState<SelectedFile[]>([]);
  const [selected, setSelected] = useState<string[]>([]);
  const [dragging, setDragging] = useState(false);
  const navigate = useNavigate();
  const session = useTransferSession();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [filterAccept, setFilterAccept] = useState<string | undefined>(undefined);
  const dragCounter = useRef(0);

  const handleFilesAdded = useCallback((fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    const newFiles: SelectedFile[] = Array.from(fileList).map((f) => {
      const type = detectType(f);
      return {
        id: crypto.randomUUID(),
        name: f.name,
        size: formatSize(f.size),
        type,
        file: f,
        thumbnail: type === "image" ? URL.createObjectURL(f) : undefined,
      };
    });
    setFiles((prev) => [...prev, ...newFiles]);
    setSelected((prev) => [...prev, ...newFiles.map((f) => f.id)]);
    toast.success(`${newFiles.length} fichier${newFiles.length > 1 ? "s" : ""} ajouté${newFiles.length > 1 ? "s" : ""}`);

    // Async video thumbnails
    newFiles.forEach((nf) => {
      if (nf.type === "video" && nf.file) {
        generateVideoThumbnail(nf.file).then((thumb) => {
          if (!thumb) return;
          setFiles((prev) => prev.map((f) => (f.id === nf.id ? { ...f, thumbnail: thumb } : f)));
        });
      }
    });
  }, []);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      files.forEach((f) => f.thumbnail && URL.revokeObjectURL(f.thumbnail));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Web Share API for selected files
  const canShare = typeof navigator !== "undefined" && "canShare" in navigator;
  const shareSelected = useCallback(async () => {
    const toShare = files.filter((f) => selected.includes(f.id) && f.file).map((f) => f.file!);
    if (toShare.length === 0) return;
    try {
      if (navigator.canShare?.({ files: toShare })) {
        await navigator.share({ files: toShare, title: "ShareDrop" });
        toast.success("Partage natif lancé");
      } else {
        toast.error("Partage natif non supporté pour ces fichiers");
      }
    } catch (err) {
      if ((err as Error).name !== "AbortError") {
        toast.error("Échec du partage natif");
      }
    }
  }, [files, selected]);

  const openPicker = (accept?: string) => {
    setFilterAccept(accept);
    setTimeout(() => fileInputRef.current?.click(), 50);
  };

  const toggle = (id: string) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const removeFile = (id: string) => {
    const file = files.find(f => f.id === id);
    setFiles((f) => f.filter((x) => x.id !== id));
    setSelected((s) => s.filter((x) => x !== id));
    if (file) toast("Fichier supprimé", { description: file.name });
  };

  /* ── Drag & Drop handlers ── */
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current++;
    if (e.dataTransfer.types.includes("Files")) setDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    dragCounter.current--;
    if (dragCounter.current === 0) setDragging(false);
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(false);
    dragCounter.current = 0;
    handleFilesAdded(e.dataTransfer.files);
  }, [handleFilesAdded]);

  const totalSize = selected.length > 0
    ? files.filter((f) => selected.includes(f.id)).reduce((acc, f) => acc + (f.file?.size || 0), 0)
    : 0;

  return (
    <div
      className="p-5 pb-40 relative"
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      {/* Hidden file input */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept={filterAccept}
        className="hidden"
        onChange={(e) => { handleFilesAdded(e.target.files); e.target.value = ""; }}
      />

      {/* Drag overlay */}
      <AnimatePresence>
        {dragging && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 bg-primary/10 backdrop-blur-sm border-2 border-dashed border-primary rounded-2xl flex flex-col items-center justify-center pointer-events-none"
          >
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mb-3"
            >
              <Upload size={28} className="text-primary" />
            </motion.div>
            <p className="text-primary font-semibold text-sm">Déposez vos fichiers ici</p>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold font-heading">Envoyer</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Sélectionnez les fichiers à transférer
        </p>
      </motion.div>

      {/* Quick actions */}
      <div className="grid grid-cols-4 gap-3 mt-6">
        {(["image", "video", "document", "apk"] as const).map((type) => {
          const Icon = typeIcons[type];
          return (
            <motion.button
              key={type}
              whileTap={{ scale: 0.92 }}
              onClick={() => openPicker(acceptMap[type])}
              className={`flex flex-col items-center gap-1.5 p-3 rounded-2xl ${typeColors[type]} transition-colors`}
            >
              <Icon size={22} />
              <span className="text-[10px] font-medium capitalize">{type === "apk" ? "APK" : type + "s"}</span>
            </motion.button>
          );
        })}
      </div>

      {/* File list */}
      <div className="mt-6 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            {files.length > 0 ? `Fichiers sélectionnés (${files.length})` : "Aucun fichier"}
          </span>
          <button onClick={() => openPicker(undefined)} className="text-xs text-primary font-medium flex items-center gap-1">
            <Plus size={14} /> Parcourir
          </button>
        </div>

        {files.length === 0 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center py-12 text-center">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-3">
              <Upload size={28} className="text-primary" />
            </div>
            <p className="text-sm text-muted-foreground">
              Glissez-déposez vos fichiers ici<br />
              ou appuyez sur un type ci-dessus /{" "}
              <button onClick={() => openPicker()} className="text-primary font-medium">"Parcourir"</button>
            </p>
          </motion.div>
        )}

        <AnimatePresence mode="popLayout">
          {files.map((file, i) => {
            const Icon = typeIcons[file.type];
            const isSelected = selected.includes(file.id);
            return (
              <motion.div
                key={file.id}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20, height: 0 }}
                transition={{ delay: i * 0.02 }}
                onClick={() => toggle(file.id)}
                className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all ${
                  isSelected ? "bg-primary/10 ring-2 ring-primary/30" : "bg-card hover:bg-secondary"
                }`}
              >
                {file.thumbnail ? (
                  <img
                    src={file.thumbnail}
                    alt={file.name}
                    loading="lazy"
                    className="w-10 h-10 rounded-lg object-cover ring-1 ring-border"
                  />
                ) : (
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${typeColors[file.type]}`}>
                    <Icon size={18} />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{file.name}</p>
                  <p className="text-xs text-muted-foreground">{file.size}</p>
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); removeFile(file.id); }}
                  className="w-6 h-6 rounded-full bg-destructive/10 flex items-center justify-center hover:bg-destructive/20 transition-colors"
                >
                  <X size={12} className="text-destructive" />
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Send button */}
      <AnimatePresence>
        {selected.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 w-full max-w-md px-5 z-50"
          >
            <Button
              onClick={() => {
                const toSend = files
                  .filter((f) => selected.includes(f.id) && f.file)
                  .map((f) => f.file!);
                if (toSend.length === 0) return;
                if (session.phase === "idle" || session.phase === "failed" || session.phase === "disconnected") {
                  toast.info("Établissez d'abord la connexion via QR");
                  navigate("/connect");
                  return;
                }
                session.queueFiles(toSend);
                toast.info("Transfert en cours...");
                navigate("/transfer");
              }}
              className="w-full h-14 rounded-2xl bg-primary text-primary-foreground text-base font-semibold shadow-lg shadow-primary/25 gap-2"
            >
              <Send size={18} />
              Envoyer {selected.length} fichier{selected.length > 1 ? "s" : ""}
              <ArrowRight size={16} />
            </Button>
            {canShare && (
              <Button
                variant="outline"
                onClick={shareSelected}
                className="w-full h-11 rounded-2xl mt-2 gap-2 text-sm"
              >
                <Share2 size={14} />
                Partager via le système
              </Button>
            )}
            {totalSize > 0 && (
              <p className="text-center text-xs text-muted-foreground mt-2">{formatSize(totalSize)}</p>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
