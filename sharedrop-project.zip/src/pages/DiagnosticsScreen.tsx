import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Activity,
  ArrowLeft,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Loader2,
  Server,
  Globe,
  Network,
  PlayCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  runWebRTCDiagnostics,
  describeMode,
  type DiagnosticsResult,
} from "@/lib/webrtc-diagnostics";
import { hasTurnConfigured } from "@/lib/webrtc-signaling";

type Phase = "idle" | "running" | "done" | "error";

const toneClass = {
  success: "text-receive bg-receive/10 border-receive/30",
  warning: "text-connect bg-connect/10 border-connect/30",
  error: "text-destructive bg-destructive/10 border-destructive/30",
} as const;

function ToneIcon({ tone, size = 20 }: { tone: "success" | "warning" | "error"; size?: number }) {
  if (tone === "success") return <CheckCircle2 size={size} aria-hidden />;
  if (tone === "warning") return <AlertTriangle size={size} aria-hidden />;
  return <XCircle size={size} aria-hidden />;
}

function MetricRow({
  icon: Icon,
  label,
  value,
  tone,
}: {
  icon: typeof Server;
  label: string;
  value: string;
  tone: "success" | "warning" | "error";
}) {
  return (
    <div className="flex items-center justify-between p-3 rounded-xl bg-card border border-border/50">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-secondary flex items-center justify-center">
          <Icon size={16} className="text-muted-foreground" />
        </div>
        <span className="text-sm font-medium">{label}</span>
      </div>
      <div className={`flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full border ${toneClass[tone]}`}>
        <ToneIcon tone={tone} size={14} />
        <span>{value}</span>
      </div>
    </div>
  );
}

export default function DiagnosticsScreen() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState<Phase>("idle");
  const [result, setResult] = useState<DiagnosticsResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const startedOnce = useRef(false);

  const start = useCallback(async () => {
    setPhase("running");
    setError(null);
    try {
      const r = await runWebRTCDiagnostics();
      setResult(r);
      setPhase("done");
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setPhase("error");
    }
  }, []);

  // Auto-run on first mount.
  useEffect(() => {
    if (startedOnce.current) return;
    startedOnce.current = true;
    void start();
  }, [start]);

  const turnConfigured = hasTurnConfigured();

  return (
    <div className="p-5 pb-24">
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-3 mb-6"
      >
        <button
          onClick={() => navigate(-1)}
          aria-label="Retour"
          className="w-9 h-9 rounded-full bg-card flex items-center justify-center hover:bg-secondary transition-colors"
        >
          <ArrowLeft size={18} />
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold font-heading">Diagnostic réseau</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Vérifie STUN, TURN et la traversée NAT avant le transfert.
          </p>
        </div>
        <Activity size={22} className="text-primary" />
      </motion.div>

      {/* Status banner */}
      <motion.div
        key={phase}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        role="status"
        aria-live="polite"
        className="rounded-2xl p-4 mb-5 border border-border/50 bg-card"
      >
        {phase === "running" && (
          <div className="flex items-center gap-3">
            <Loader2 className="text-primary animate-spin" size={22} />
            <div>
              <p className="text-sm font-semibold">Analyse en cours…</p>
              <p className="text-xs text-muted-foreground">Test des serveurs STUN/TURN</p>
            </div>
          </div>
        )}

        {phase === "done" && result && (() => {
          const desc = describeMode(result.mode);
          return (
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${toneClass[desc.tone]}`}>
                <ToneIcon tone={desc.tone} size={20} />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold">{desc.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Mode <span className="font-mono uppercase">{result.mode}</span> · {result.candidates.length} candidat(s) collecté(s) en {result.durationMs} ms
                </p>
              </div>
            </div>
          );
        })()}

        {phase === "error" && (
          <div className="flex items-center gap-3">
            <XCircle className="text-destructive" size={22} />
            <div>
              <p className="text-sm font-semibold">Diagnostic impossible</p>
              <p className="text-xs text-muted-foreground">{error ?? "Erreur inconnue"}</p>
            </div>
          </div>
        )}

        {phase === "idle" && (
          <p className="text-sm text-muted-foreground">Lance le test pour vérifier la connectivité.</p>
        )}
      </motion.div>

      {/* Metrics */}
      {result && phase === "done" && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-2"
        >
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider px-1">
            Détails
          </span>

          <MetricRow
            icon={Network}
            label="Candidat local (host)"
            value={
              result.candidates.some((c) => c.type === "host")
                ? `${result.firstCandidateMs ?? 0} ms`
                : "Absent"
            }
            tone={result.candidates.some((c) => c.type === "host") ? "success" : "warning"}
          />

          <MetricRow
            icon={Globe}
            label="STUN (NAT public)"
            value={result.hasStun ? `${result.firstSrflxMs} ms` : "Indisponible"}
            tone={result.hasStun ? "success" : "warning"}
          />

          <MetricRow
            icon={Server}
            label="TURN (relais)"
            value={
              result.hasTurn
                ? `${result.firstRelayMs} ms`
                : turnConfigured
                  ? "Échec"
                  : "Non configuré"
            }
            tone={result.hasTurn ? "success" : turnConfigured ? "error" : "warning"}
          />

          {result.errors.length > 0 && (
            <div className="mt-3 p-3 rounded-xl bg-destructive/10 border border-destructive/30">
              <p className="text-xs font-semibold text-destructive mb-1">Erreurs ICE</p>
              <ul className="text-xs text-muted-foreground space-y-0.5">
                {result.errors.map((e, i) => (
                  <li key={i} className="font-mono">{e}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Recommendation */}
          <div className="mt-4 p-4 rounded-xl bg-secondary/50 border border-border/50">
            <p className="text-xs font-semibold mb-1">Recommandation</p>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {result.mode === "turn" &&
                "Connectivité optimale. Les transferts fonctionneront même derrière un pare-feu strict."}
              {result.mode === "stun" &&
                "P2P direct disponible. Sans TURN, ~10–20 % des connexions peuvent échouer derrière des NAT symétriques."}
              {result.mode === "host" &&
                "Seules les connexions sur le même réseau local fonctionneront. Configure un serveur TURN pour le distant."}
              {result.mode === "blocked" &&
                "Aucune connectivité WebRTC. Vérifie le pare-feu, le VPN ou les permissions réseau du navigateur."}
            </p>
          </div>
        </motion.div>
      )}

      {/* Actions */}
      <div className="mt-6 flex gap-3">
        <Button
          onClick={start}
          disabled={phase === "running"}
          className="flex-1 h-11 rounded-xl"
        >
          {phase === "running" ? (
            <Loader2 className="animate-spin" size={18} />
          ) : (
            <>
              <PlayCircle size={18} className="mr-2" />
              Relancer le test
            </>
          )}
        </Button>
        <Button
          variant="outline"
          onClick={() => navigate("/connect")}
          disabled={phase === "running"}
          className="flex-1 h-11 rounded-xl"
        >
          Continuer
        </Button>
      </div>
    </div>
  );
}
