import { motion } from "framer-motion";
import { ArrowUpRight, ArrowDownLeft, Image, Video, FileText, Share2 } from "lucide-react";
import { toast } from "sonner";

const history = [
  { name: "vacances_2024.jpg", size: "4.2 MB", type: "image", direction: "sent", device: "MacBook Pro", time: "il y a 5 min" },
  { name: "presentation.mp4", size: "1.2 GB", type: "video", direction: "sent", device: "MacBook Pro", time: "il y a 5 min" },
  { name: "notes.pdf", size: "320 KB", type: "document", direction: "received", device: "Galaxy S23", time: "il y a 2h" },
  { name: "photo_groupe.jpg", size: "8.1 MB", type: "image", direction: "received", device: "iPhone 15", time: "hier" },
];

const icons = { image: Image, video: Video, document: FileText };

const canShare = typeof navigator !== "undefined" && "share" in navigator;

async function shareEntry(item: { name: string; device: string }) {
  try {
    await navigator.share({
      title: "ShareDrop",
      text: `${item.name} — transféré avec ${item.device}`,
    });
  } catch (err) {
    if ((err as Error).name !== "AbortError") {
      toast.error("Partage indisponible");
    }
  }
}

export default function HistoryScreen() {
  return (
    <div className="p-5">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold font-heading">Historique</h1>
        <p className="text-muted-foreground text-sm mt-1">Transferts récents</p>
      </motion.div>

      <div className="mt-6 space-y-2">
        {history.map((item, i) => {
          const Icon = icons[item.type as keyof typeof icons] || FileText;
          const isSent = item.direction === "sent";
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center gap-3 p-3 rounded-xl bg-card"
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                isSent ? "bg-primary/10" : "bg-receive/10"
              }`}>
                <Icon size={18} className={isSent ? "text-primary" : "text-receive"} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{item.name}</p>
                <p className="text-xs text-muted-foreground">{item.device} • {item.time}</p>
              </div>
              <div className={`flex items-center gap-1 text-xs ${
                isSent ? "text-primary" : "text-receive"
              }`}>
                {isSent ? <ArrowUpRight size={12} /> : <ArrowDownLeft size={12} />}
                {item.size}
              </div>
              {canShare && (
                <button
                  onClick={() => shareEntry(item)}
                  className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center hover:bg-secondary/70 transition-colors"
                  aria-label={`Partager ${item.name}`}
                >
                  <Share2 size={14} className="text-muted-foreground" />
                </button>
              )}
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
