import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Download, Shield, Wifi, ArrowRight, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

const slides = [
  {
    icon: Wifi,
    color: "bg-primary",
    title: "Sans internet",
    desc: "Transférez vos fichiers via Wi-Fi Direct ou hotspot local. Aucune connexion internet nécessaire.",
  },
  {
    icon: Send,
    color: "bg-accent",
    title: "Ultra rapide",
    desc: "Envoyez photos, vidéos, documents et APK à pleine vitesse Wi-Fi. Même les fichiers de +1 Go.",
  },
  {
    icon: Shield,
    color: "bg-receive",
    title: "100% sécurisé",
    desc: "Vos fichiers restent sur vos appareils. Code PIN, chiffrement local et aucun cloud.",
  },
];

interface OnboardingScreenProps {
  onComplete: () => void;
}

export default function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const [current, setCurrent] = useState(0);

  const next = () => {
    if (current < slides.length - 1) {
      setCurrent(current + 1);
    } else {
      onComplete();
    }
  };

  const prev = () => {
    if (current > 0) setCurrent(current - 1);
  };

  const slide = slides[current];
  const Icon = slide.icon;

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto p-6">
      {/* Skip */}
      <div className="flex justify-end">
        <button onClick={onComplete} className="text-xs text-muted-foreground hover:text-foreground transition-colors">
          Passer
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center text-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={current}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col items-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className={`w-28 h-28 rounded-[2rem] ${slide.color} flex items-center justify-center shadow-lg mb-8`}
            >
              <Icon size={48} className="text-white" />
            </motion.div>

            <h1 className="text-2xl font-bold font-heading mb-3">{slide.title}</h1>
            <p className="text-muted-foreground text-sm max-w-[280px] leading-relaxed">
              {slide.desc}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Dots */}
      <div className="flex justify-center gap-2 mb-8">
        {slides.map((_, i) => (
          <motion.div
            key={i}
            animate={{
              width: i === current ? 24 : 8,
              backgroundColor: i === current ? "hsl(var(--primary))" : "hsl(var(--muted))",
            }}
            className="h-2 rounded-full"
            transition={{ duration: 0.3 }}
          />
        ))}
      </div>

      {/* Navigation */}
      <div className="flex gap-3">
        {current > 0 && (
          <Button
            variant="outline"
            onClick={prev}
            className="h-14 w-14 rounded-2xl"
          >
            <ChevronLeft size={20} />
          </Button>
        )}
        <Button
          onClick={next}
          className="flex-1 h-14 rounded-2xl bg-primary text-primary-foreground text-base font-semibold gap-2"
        >
          {current === slides.length - 1 ? "Commencer" : "Suivant"}
          <ArrowRight size={16} />
        </Button>
      </div>
    </div>
  );
}
