import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Send, Download, Wifi, Zap, Shield, Smartphone, ArrowRight, Signal } from "lucide-react";
import { Button } from "@/components/ui/button";

const features = [
  { icon: Zap, title: "Ultra rapide", desc: "Transfert à pleine vitesse Wi-Fi", color: "text-primary" },
  { icon: Shield, title: "100% sécurisé", desc: "Chiffrement local, aucun cloud", color: "text-receive" },
  { icon: Signal, title: "Sans internet", desc: "Fonctionne hors connexion", color: "text-connect" },
];

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="p-5 pb-24 flex flex-col min-h-screen">
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center pt-8 pb-6"
      >
        {/* Logo */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.1 }}
          className="mx-auto w-20 h-20 rounded-3xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-lg shadow-primary/30 mb-5"
        >
          <Wifi size={36} className="text-primary-foreground" />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-3xl font-bold font-heading"
        >
          Share<span className="text-primary">Drop</span>
        </motion.h1>
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-muted-foreground text-sm mt-2 max-w-[260px] mx-auto"
        >
          Partagez vos fichiers instantanément, sans internet, en toute sécurité.
        </motion.p>
      </motion.div>

      {/* Quick actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35 }}
        className="grid grid-cols-2 gap-3 mb-6"
      >
        <Button
          onClick={() => navigate("/send")}
          className="h-24 rounded-2xl bg-primary text-primary-foreground flex-col gap-2 shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-shadow"
        >
          <Send size={24} />
          <span className="text-sm font-semibold">Envoyer</span>
        </Button>
        <Button
          onClick={() => navigate("/receive")}
          variant="outline"
          className="h-24 rounded-2xl flex-col gap-2 border-receive/30 hover:bg-receive/5 text-receive"
        >
          <Download size={24} />
          <span className="text-sm font-semibold">Recevoir</span>
        </Button>
      </motion.div>

      {/* Connect PC button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <button
          onClick={() => navigate("/connect")}
          className="w-full flex items-center gap-4 p-4 rounded-2xl bg-connect/5 border border-connect/20 hover:bg-connect/10 transition-colors group"
        >
          <div className="w-12 h-12 rounded-xl bg-connect/10 flex items-center justify-center">
            <Smartphone size={22} className="text-connect" />
          </div>
          <div className="flex-1 text-left">
            <p className="text-sm font-semibold">Connecter un PC</p>
            <p className="text-xs text-muted-foreground">Via QR code ou IP locale</p>
          </div>
          <ArrowRight size={18} className="text-muted-foreground group-hover:text-connect transition-colors" />
        </button>
      </motion.div>

      {/* Features */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-8 space-y-3"
      >
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Pourquoi ShareDrop ?
        </span>
        {features.map((feat, i) => (
          <motion.div
            key={feat.title}
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.55 + i * 0.1 }}
            className="flex items-center gap-3 p-3 rounded-xl bg-card"
          >
            <div className="w-10 h-10 rounded-lg bg-secondary flex items-center justify-center">
              <feat.icon size={18} className={feat.color} />
            </div>
            <div>
              <p className="text-sm font-medium">{feat.title}</p>
              <p className="text-xs text-muted-foreground">{feat.desc}</p>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Version */}
      <div className="mt-auto pt-6 text-center">
        <p className="text-[10px] text-muted-foreground">ShareDrop v1.0.0 • 100% Offline</p>
      </div>
    </div>
  );
}
