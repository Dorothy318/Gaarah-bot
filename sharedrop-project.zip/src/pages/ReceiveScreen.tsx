import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Download, ScanLine, ShieldCheck, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import QRScanner from "@/components/QRScanner";
import { decodeRoomInvite } from "@/lib/webrtc-signaling";
import { useTransferSession } from "@/contexts/TransferSession";

export default function ReceiveScreen() {
  const navigate = useNavigate();
  const session = useTransferSession();
  const [showScanner, setShowScanner] = useState(false);

  // Once we have a live guest session, jump straight to the transfer screen.
  useEffect(() => {
    if (
      session.role === "guest" &&
      (session.phase === "waiting" || session.phase === "connecting" || session.phase === "connected" || session.phase === "transferring")
    ) {
      navigate("/transfer");
    }
  }, [session.role, session.phase, navigate]);

  const handleScan = (data: string) => {
    setShowScanner(false);
    const invite = decodeRoomInvite(data);
    if (!invite) {
      toast.error("QR Code invalide", { description: "Format ShareDrop attendu" });
      return;
    }
    toast.success("Invitation détectée", { description: `Salon ${invite.room}…` });
    void session.startAsGuest(invite.room, invite.token);
    setTimeout(() => navigate("/transfer"), 300);
  };

  const busy = session.role === "guest" && (session.phase === "joining" || session.phase === "connecting");

  return (
    <div className="p-5">
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <h1 className="text-2xl font-bold font-heading">Recevoir</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Scannez le QR code de l'émetteur pour ouvrir un canal P2P chiffré.
        </p>
      </motion.div>

      <div className="flex items-center justify-center my-10">
        <motion.div
          whileTap={{ scale: 0.95 }}
          className="relative w-40 h-40 rounded-full bg-receive/10 flex items-center justify-center"
        >
          <span className="absolute inset-0 rounded-full border-2 border-receive/30 animate-pulse-ring" />
          <div className="w-24 h-24 rounded-full bg-receive/20 flex items-center justify-center">
            <div className="w-16 h-16 rounded-full bg-receive flex items-center justify-center shadow-lg shadow-receive/30">
              {busy ? (
                <Loader2 size={28} className="text-receive-foreground animate-spin" />
              ) : (
                <Download size={28} className="text-receive-foreground" />
              )}
            </div>
          </div>
        </motion.div>
      </div>

      <div className="space-y-3">
        <Button
          onClick={() => setShowScanner(true)}
          disabled={busy}
          className="w-full h-14 rounded-2xl bg-primary text-primary-foreground text-base font-semibold gap-2"
        >
          <ScanLine size={18} />
          Scanner le QR d'invitation
        </Button>

        <div className="flex items-start gap-2 p-3 rounded-xl bg-card border border-border text-xs text-muted-foreground">
          <ShieldCheck size={16} className="text-connect shrink-0 mt-0.5" />
          <span>
            Chaque salon est protégé par un jeton HMAC partagé via le QR.
            Les fichiers reçus sont vérifiés par empreinte SHA-256 avant d'être proposés au téléchargement.
          </span>
        </div>
      </div>

      {showScanner && (
        <QRScanner onScan={handleScan} onClose={() => setShowScanner(false)} />
      )}
    </div>
  );
}
