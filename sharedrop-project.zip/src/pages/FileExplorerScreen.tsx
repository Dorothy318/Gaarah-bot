import { useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FolderOpen, Folder, Image, Video, FileText, Package, File,
  ChevronRight, ArrowLeft, Plus, Check, X, Search,
  HardDrive, Camera, Music, Download as DownloadIcon, Smartphone,
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

/* ── Types ── */
interface VirtualFile {
  id: string;
  name: string;
  size: number;
  type: "image" | "video" | "document" | "apk" | "other";
  file: File;
}

interface BreadcrumbItem {
  name: string;
  handle: FileSystemDirectoryHandle | null;
}

/* ── Helpers ── */
const typeIcons = { image: Image, video: Video, document: FileText, apk: Package, other: File };
const typeColors: Record<string, string> = {
  image: "bg-primary/10 text-primary",
  video: "bg-accent/10 text-accent",
  document: "bg-connect/10 text-connect",
  apk: "bg-destructive/10 text-destructive",
  other: "bg-muted text-muted-foreground",
};

function detectType(name: string, mime: string): VirtualFile["type"] {
  const ext = name.split(".").pop()?.toLowerCase() || "";
  if (mime.startsWith("image/") || ["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp"].includes(ext)) return "image";
  if (mime.startsWith("video/") || ["mp4", "mkv", "avi", "mov", "webm"].includes(ext)) return "video";
  if (["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv"].includes(ext)) return "document";
  if (ext === "apk") return "apk";
  return "other";
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  if (bytes < 1024 ** 3) return (bytes / 1024 ** 2).toFixed(1) + " MB";
  return (bytes / 1024 ** 3).toFixed(2) + " GB";
}

interface DirEntry {
  kind: "file" | "directory";
  name: string;
  handle: FileSystemDirectoryHandle | FileSystemFileHandle;
}

/* ── Quick access categories ── */
const quickCategories = [
  { id: "images", label: "Images", icon: Camera, accept: "image/*", color: "bg-primary/10 text-primary" },
  { id: "videos", label: "Vidéos", icon: Video, accept: "video/*", color: "bg-accent/10 text-accent" },
  { id: "audio", label: "Audio", icon: Music, accept: "audio/*", color: "bg-receive/10 text-receive" },
  { id: "docs", label: "Documents", icon: FileText, accept: ".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv", color: "bg-connect/10 text-connect" },
  { id: "downloads", label: "Téléchargements", icon: DownloadIcon, accept: "*/*", color: "bg-destructive/10 text-destructive" },
  { id: "apk", label: "APK", icon: Package, accept: ".apk", color: "bg-muted text-foreground" },
];

export default function FileExplorerScreen() {
  const navigate = useNavigate();
  const [rootHandle, setRootHandle] = useState<FileSystemDirectoryHandle | null>(null);
  const [entries, setEntries] = useState<DirEntry[]>([]);
  const [breadcrumbs, setBreadcrumbs] = useState<BreadcrumbItem[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [previewName, setPreviewName] = useState("");

  const fallbackRef = useRef<HTMLInputElement>(null);
  const categoryRef = useRef<HTMLInputElement>(null);
  const [fallbackFiles, setFallbackFiles] = useState<VirtualFile[]>([]);
  const supportsFS = "showDirectoryPicker" in window;

  const readDir = useCallback(async (handle: FileSystemDirectoryHandle) => {
    setLoading(true);
    const items: DirEntry[] = [];
    for await (const entry of (handle as any).values()) {
      items.push({ kind: entry.kind, name: entry.name, handle: entry });
    }
    items.sort((a, b) => {
      if (a.kind !== b.kind) return a.kind === "directory" ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
    setEntries(items);
    setSelected(new Set());
    setLoading(false);
  }, []);

  const openRoot = async () => {
    try {
      const handle = await (window as any).showDirectoryPicker();
      setRootHandle(handle);
      setBreadcrumbs([{ name: handle.name, handle }]);
      await readDir(handle);
    } catch { /* cancelled */ }
  };

  const openSubDir = async (entry: DirEntry) => {
    if (entry.kind !== "directory") return;
    const dirHandle = entry.handle as FileSystemDirectoryHandle;
    setBreadcrumbs((prev) => [...prev, { name: entry.name, handle: dirHandle }]);
    await readDir(dirHandle);
  };

  const goBack = async () => {
    if (breadcrumbs.length <= 1) {
      setRootHandle(null);
      setEntries([]);
      setBreadcrumbs([]);
      return;
    }
    const newCrumbs = breadcrumbs.slice(0, -1);
    setBreadcrumbs(newCrumbs);
    await readDir(newCrumbs[newCrumbs.length - 1].handle!);
  };

  const navigateToCrumb = async (index: number) => {
    if (index === breadcrumbs.length - 1) return;
    const newCrumbs = breadcrumbs.slice(0, index + 1);
    setBreadcrumbs(newCrumbs);
    await readDir(newCrumbs[newCrumbs.length - 1].handle!);
  };

  const previewFile = async (entry: DirEntry) => {
    if (entry.kind !== "file") return;
    const file = await (entry.handle as FileSystemFileHandle).getFile();
    if (file.type.startsWith("image/")) {
      setPreviewUrl(URL.createObjectURL(file));
      setPreviewName(file.name);
    }
  };

  const toggleSelect = (name: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(name) ? next.delete(name) : next.add(name);
      return next;
    });
  };

  const handleFallbackFiles = (fileList: FileList | null) => {
    if (!fileList) return;
    const newFiles: VirtualFile[] = Array.from(fileList).map((f) => ({
      id: crypto.randomUUID(),
      name: f.name,
      size: f.size,
      type: detectType(f.name, f.type),
      file: f,
    }));
    setFallbackFiles((prev) => [...prev, ...newFiles]);
  };

  const openCategory = (accept: string) => {
    if (categoryRef.current) {
      categoryRef.current.accept = accept;
      categoryRef.current.click();
    }
  };

  const filteredEntries = entries.filter((e) =>
    e.name.toLowerCase().includes(search.toLowerCase())
  );
  const filteredFallback = fallbackFiles.filter((f) =>
    f.name.toLowerCase().includes(search.toLowerCase())
  );

  const sendSelected = () => navigate("/send");
  const selectedCount = supportsFS ? selected.size : fallbackFiles.filter((f) => selected.has(f.id)).length;

  return (
    <div className="p-5 pb-40">
      <input ref={fallbackRef} type="file" multiple className="hidden" onChange={(e) => { handleFallbackFiles(e.target.files); e.target.value = ""; }} />
      <input ref={categoryRef} type="file" multiple className="hidden" onChange={(e) => { handleFallbackFiles(e.target.files); e.target.value = ""; }} />

      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 mb-1">
        {rootHandle && (
          <button onClick={goBack} className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center">
            <ArrowLeft size={16} className="text-foreground" />
          </button>
        )}
        <div>
          <h1 className="text-2xl font-bold font-heading">Explorateur</h1>
          <p className="text-muted-foreground text-sm">Accédez à la mémoire de votre appareil</p>
        </div>
      </motion.div>

      {/* Search */}
      {(rootHandle || fallbackFiles.length > 0) && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4 relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher..."
            className="w-full h-10 pl-9 pr-4 rounded-xl bg-secondary text-sm text-foreground placeholder:text-muted-foreground outline-none border border-border focus:border-primary transition-colors"
          />
        </motion.div>
      )}

      {/* Breadcrumbs */}
      {breadcrumbs.length > 0 && (
        <div className="flex items-center gap-1 mt-3 overflow-x-auto text-xs text-muted-foreground">
          {breadcrumbs.map((crumb, i) => (
            <span key={i} className="flex items-center gap-1 shrink-0">
              {i > 0 && <ChevronRight size={12} />}
              <button
                onClick={() => navigateToCrumb(i)}
                className={`hover:text-primary transition-colors ${i === breadcrumbs.length - 1 ? "text-foreground font-medium" : ""}`}
              >
                {crumb.name}
              </button>
            </span>
          ))}
        </div>
      )}

      {/* Landing: no folder opened */}
      {!rootHandle && fallbackFiles.length === 0 && (
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
          {/* Storage info card */}
          <div className="mt-5 p-4 bg-card rounded-2xl border border-border">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                <Smartphone size={20} className="text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold">Mémoire interne</p>
                <p className="text-xs text-muted-foreground">Stockage de l'appareil</p>
              </div>
            </div>
            <div className="w-full h-2 bg-secondary rounded-full overflow-hidden">
              <div className="h-full w-[62%] bg-gradient-to-r from-primary to-primary/60 rounded-full" />
            </div>
            <p className="text-[10px] text-muted-foreground mt-1">49,6 Go utilisés sur 128 Go</p>
          </div>

          {/* Quick categories */}
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mt-5 mb-3">Accès rapide</p>
          <div className="grid grid-cols-3 gap-2">
            {quickCategories.map((cat) => (
              <motion.button
                key={cat.id}
                whileTap={{ scale: 0.95 }}
                onClick={() => openCategory(cat.accept)}
                className={`flex flex-col items-center gap-2 p-4 rounded-xl ${cat.color} transition-colors`}
              >
                <cat.icon size={22} />
                <span className="text-[10px] font-medium">{cat.label}</span>
              </motion.button>
            ))}
          </div>

          {/* Open folder button */}
          <div className="flex gap-3 mt-6">
            {supportsFS ? (
              <Button onClick={openRoot} className="flex-1 h-12 rounded-xl bg-primary text-primary-foreground gap-2">
                <HardDrive size={18} />
                Ouvrir un dossier
              </Button>
            ) : (
              <Button onClick={() => fallbackRef.current?.click()} className="flex-1 h-12 rounded-xl bg-primary text-primary-foreground gap-2">
                <Plus size={18} />
                Choisir des fichiers
              </Button>
            )}
          </div>
        </motion.div>
      )}

      {/* File System Access entries */}
      {rootHandle && (
        <div className="mt-4 space-y-1.5">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          ) : filteredEntries.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground py-8">Dossier vide</p>
          ) : (
            <AnimatePresence mode="popLayout">
              {filteredEntries.map((entry, i) => {
                const isDir = entry.kind === "directory";
                const ext = entry.name.split(".").pop()?.toLowerCase() || "";
                const fileType = isDir ? "other" : detectType(entry.name, "");
                const Icon = isDir ? Folder : typeIcons[fileType];
                const colorClass = isDir ? "bg-connect/10 text-connect" : typeColors[fileType];
                const isSelected = selected.has(entry.name);
                return (
                  <motion.div
                    key={entry.name}
                    layout
                    initial={{ opacity: 0, x: -16 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 16 }}
                    transition={{ delay: i * 0.015 }}
                    onClick={() => (isDir ? openSubDir(entry) : toggleSelect(entry.name))}
                    onDoubleClick={() => !isDir && previewFile(entry)}
                    className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all ${
                      isSelected ? "bg-primary/10 ring-2 ring-primary/30" : "bg-card hover:bg-secondary"
                    }`}
                  >
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${colorClass}`}>
                      <Icon size={18} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{entry.name}</p>
                      <p className="text-[10px] text-muted-foreground uppercase">{isDir ? "Dossier" : ext}</p>
                    </div>
                    {isDir ? (
                      <ChevronRight size={16} className="text-muted-foreground shrink-0" />
                    ) : isSelected ? (
                      <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center shrink-0">
                        <Check size={12} className="text-primary-foreground" />
                      </div>
                    ) : null}
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>
      )}

      {/* Fallback file list */}
      {!supportsFS && fallbackFiles.length > 0 && (
        <div className="mt-4 space-y-1.5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Fichiers ({fallbackFiles.length})
            </span>
            <button onClick={() => fallbackRef.current?.click()} className="text-xs text-primary font-medium flex items-center gap-1">
              <Plus size={14} /> Ajouter
            </button>
          </div>
          <AnimatePresence mode="popLayout">
            {filteredFallback.map((file, i) => {
              const Icon = typeIcons[file.type];
              const isSelected = selected.has(file.id);
              return (
                <motion.div
                  key={file.id}
                  layout
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 16 }}
                  transition={{ delay: i * 0.015 }}
                  onClick={() => toggleSelect(file.id)}
                  className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all ${
                    isSelected ? "bg-primary/10 ring-2 ring-primary/30" : "bg-card hover:bg-secondary"
                  }`}
                >
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${typeColors[file.type]}`}>
                    <Icon size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{formatSize(file.size)}</p>
                  </div>
                  {isSelected && (
                    <div className="w-6 h-6 rounded-full bg-primary flex items-center justify-center shrink-0">
                      <Check size={12} className="text-primary-foreground" />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      )}

      {/* Image preview overlay */}
      <AnimatePresence>
        {previewUrl && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setPreviewUrl(null)}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-6"
          >
            <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }} exit={{ scale: 0.8 }} className="relative max-w-full max-h-full">
              <button onClick={() => setPreviewUrl(null)} className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-card flex items-center justify-center shadow-lg z-10">
                <X size={16} className="text-foreground" />
              </button>
              <img src={previewUrl} alt={previewName} className="max-w-full max-h-[70vh] rounded-2xl object-contain" />
              <p className="text-center text-sm text-white/80 mt-3">{previewName}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Send selected */}
      <AnimatePresence>
        {selectedCount > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 30 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 w-full max-w-md px-5 z-50"
          >
            <Button onClick={sendSelected} className="w-full h-14 rounded-2xl bg-primary text-primary-foreground text-base font-semibold shadow-lg shadow-primary/25 gap-2">
              Envoyer {selectedCount} fichier{selectedCount > 1 ? "s" : ""}
              <ChevronRight size={16} />
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
