import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Check, X, Wifi, Image, Video, FileText, Package, File, Download, AlertTriangle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { notifyIfBackground } from "@/lib/notifications";
import { useTransferSession, type TransferItem } from "@/contexts/TransferSession";
import { formatSize, formatSpeed, detectType } from "@/lib/file-utils";

const typeIcons = { image: Image, video: Video, document: FileText, apk: Package, other: File };
const typeColors: Record<string, string> = {
  image: "bg-primary/10 text-primary",
  video: "bg-accent/10 text-accent",
  document: "bg-connect/10 text-connect",
  apk: "bg-destructive/10 text-destructive",
  other: "bg-muted text-muted-foreground",
};

function downloadBlob(item: TransferItem) {
  if (!item.blob) return;
  const url = URL.createObjectURL(item.blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = item.name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

export default function TransferScreen() {
  const navigate = useNavigate();
  const { t } = useTranslation();
  const session = useTransferSession();
  const { transfers, phase, role, pendingCount, error } = session;

  // Speed calculation via delta of bytesTransferred
  const speedRef = useRef({ bytes: 0, ts: Date.now(), speed: 0 });
  const totalBytesTransferred = transfers.reduce((a, t) => a + t.bytesTransferred, 0);
  const totalBytes = transfers.reduce((a, t) => a + t.size, 0);
  const now = Date.now();
  const dt = (now - speedRef.current.ts) / 1000;
  if (dt > 0.5) {
    const delta = totalBytesTransferred - speedRef.current.bytes;
    speedRef.current.speed = Math.max(0, delta / dt);
    speedRef.current.bytes = totalBytesTransferred;
    speedRef.current.ts = now;
  }
  const currentSpeed = formatSpeed(speedRef.current.speed);

  const globalProgress = totalBytes > 0
    ? Math.min(Math.round((totalBytesTransferred / totalBytes) * 100), 100)
    : 0;

  const allDone = transfers.length > 0 &&
    transfers.every((t) => t.status === "done" || t.status === "error") &&
    pendingCount === 0 &&
    phase !== "transferring";

  const remaining = allDone
    ? "Terminé"
    : speedRef.current.speed > 0
    ? `${Math.max(1, Math.round((totalBytes - totalBytesTransferred) / speedRef.current.speed))}s`
    : "…";

  // Toast + background notif once when everything is complete
  const notifiedRef = useRef(false);
  useEffect(() => {
    if (allDone && !notifiedRef.current) {
      notifiedRef.current = true;
      setTimeout(() => toast.success("Transfert terminé ! 🎉"), 200);
      notifyIfBackground(
        t("transfer.completedTitle"),
        t("transfer.completedBody", { count: transfers.length }),
      );
    }
  }, [allDone, transfers.length, t]);

  const empty = transfers.length === 0;

  return (
    <div className="p-5 min-h-screen flex flex-col">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="text-muted-foreground" aria-label="Retour">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-lg font-bold font-heading">
            {allDone ? "Transfert terminé" : empty ? "En attente" : "Transfert en cours"}
          </h1>
          <div className="flex items-center gap-1 text-xs text-receive">
            <Wifi size={10} />
            WebRTC P2P • {role === "host" ? "Envoi" : role === "guest" ? "Réception" : "Idle"} • {phase}
          </div>
        </div>
      </div>

      {error && (
        <div className="mt-3 flex items-center gap-2 px-3 py-2 rounded-lg bg-destructive/10 border border-destructive/30 text-xs text-destructive">
          <AlertTriangle size={14} />
          {error}
        </div>
      )}

      {/* Global circular progress */}
      <div className="flex items-center justify-center py-6">
        <div className="relative w-40 h-40">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
            <circle cx="60" cy="60" r="54" fill="none" strokeWidth="8" className="stroke-secondary" />
            <motion.circle
              cx="60" cy="60" r="54" fill="none" strokeWidth="8"
              strokeLinecap="round"
              className={allDone ? "stroke-receive" : "stroke-primary"}
              strokeDasharray={339.29}
              animate={{ strokeDashoffset: 339.29 - (339.29 * globalProgress) / 100 }}
              transition={{ duration: 0.3 }}
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            {allDone ? (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="w-14 h-14 rounded-full bg-receive flex items-center justify-center"
              >
                <Check size={28} className="text-receive-foreground" />
              </motion.div>
            ) : empty ? (
              <Loader2 className="animate-spin text-muted-foreground" size={28} />
            ) : (
              <>
                <span className="text-3xl font-bold font-heading">{globalProgress}%</span>
                <span className="text-[10px] text-muted-foreground">{currentSpeed}</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Per-file progress */}
      <div className="flex-1 space-y-2 mb-4">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Fichiers ({transfers.filter((f) => f.status === "done").length}/{transfers.length})
          {pendingCount > 0 && ` • ${pendingCount} en file`}
        </span>

        {empty && (
          <p className="text-sm text-muted-foreground text-center py-8">
            {role === "guest"
              ? "En attente de fichiers de l'émetteur…"
              : "Aucun fichier en cours. Retournez à Envoyer pour en sélectionner."}
          </p>
        )}

        <AnimatePresence>
          {transfers.map((file) => {
            const type = detectType({ name: file.name, type: file.mime });
            const Icon = typeIcons[type];
            const fileProg = file.percent;
            return (
              <motion.div
                key={file.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-3 rounded-xl transition-all ${
                  file.status === "done"
                    ? "bg-receive/5 border border-receive/20"
                    : file.status === "active"
                    ? "bg-primary/5 border border-primary/20"
                    : file.status === "error"
                    ? "bg-destructive/5 border border-destructive/20"
                    : "bg-card border border-border"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${typeColors[type]}`}>
                    {file.status === "done" ? (
                      <Check size={16} className="text-receive" />
                    ) : file.status === "error" ? (
                      <AlertTriangle size={16} className="text-destructive" />
                    ) : (
                      <Icon size={16} />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium truncate pr-2">{file.name}</p>
                      <span className={`text-xs font-semibold shrink-0 ${
                        file.status === "done" ? "text-receive" : file.status === "active" ? "text-primary" : file.status === "error" ? "text-destructive" : "text-muted-foreground"
                      }`}>
                        {file.status === "done" ? "✓" : file.status === "active" ? `${fileProg}%` : file.status === "error" ? "Erreur" : "En attente"}
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-secondary mt-1.5 overflow-hidden">
                      <motion.div
                        className={`h-full rounded-full ${
                          file.status === "error" ? "bg-destructive" :
                          file.status === "done" ? "bg-receive" : "bg-primary"
                        }`}
                        animate={{ width: `${fileProg}%` }}
                        transition={{ duration: 0.3 }}
                      />
                    </div>
                    <div className="flex justify-between items-center mt-1">
                      <span className="text-[10px] text-muted-foreground">
                        {formatSize(file.size)}
                        {file.direction === "receive" && " • reçu"}
                        {file.integrityOk === false && " • intégrité KO"}
                      </span>
                      {file.direction === "receive" && file.status === "done" && file.blob && (
                        <button
                          onClick={() => downloadBlob(file)}
                          className="text-[10px] text-primary flex items-center gap-1 font-medium"
                        >
                          <Download size={10} /> Enregistrer
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Summary */}
      <div className="bg-card rounded-2xl p-3 border border-border mb-3">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Temps restant</span>
          <span className="font-medium">{remaining}</span>
        </div>
      </div>

      {/* Controls */}
      <div className="flex gap-3 mb-4">
        {allDone ? (
          <Button
            onClick={() => { void session.reset(); navigate("/"); }}
            className="flex-1 h-14 rounded-2xl bg-receive text-receive-foreground text-base font-semibold"
          >
            <Check size={18} className="mr-2" />
            Terminé
          </Button>
        ) : (
          <Button
            variant="outline"
            onClick={() => { void session.reset(); toast.error("Transfert annulé"); navigate("/"); }}
            className="flex-1 h-14 rounded-2xl gap-2"
          >
            <X size={18} />
            Annuler
          </Button>
        )}
      </div>
    </div>
  );
}
