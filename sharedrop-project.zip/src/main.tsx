import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";
import "@/lib/i18n";
import { initReporter } from "@/lib/reporter";
import { initAnalytics } from "@/lib/analytics";


// Apply persisted dark-mode preference before first paint
const savedDark = localStorage.getItem("sharedrop_dark");
const prefersDark =
  savedDark !== null
    ? savedDark === "true"
    : window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? true;
document.documentElement.classList.toggle("dark", prefersDark);

initReporter();
initAnalytics();

createRoot(document.getElementById("root")!).render(<App />);
