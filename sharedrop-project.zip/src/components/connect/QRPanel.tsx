import { motion } from "framer-motion";
import { Check, Globe, Shield, ScanLine, Monitor } from "lucide-react";
import { QRCodeSVG } from "qrcode.react";
import { Button } from "@/components/ui/button";
import type { PeerStatus } from "@/hooks/useWebRTCPeer";

interface QRPanelProps {
  inviteUrl: string;
  room: string;
  pin: string;
  peerStatus: PeerStatus;
  scannedResult: string | null;
  onRescan: () => void;
  onScannerOpen: () => void;
  onPCInterface: () => void;
  onSend: () => void;
}

export default function QRPanel({
  inviteUrl, room, pin, peerStatus, scannedResult,
  onRescan, onScannerOpen, onPCInterface, onSend,
}: QRPanelProps) {
  const statusLabel =
    peerStatus === "connected" ? "Connecté" :
    peerStatus === "connecting" ? "Connexion…" :
    peerStatus === "waiting" ? "En attente" : pin;

  return (
    <motion.div
      key="qr"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="mt-6 flex flex-col items-center"
    >
      {scannedResult ? (
        <div className="bg-card p-6 rounded-2xl shadow-lg border border-border text-center w-full">
          <div className="w-14 h-14 mx-auto rounded-full bg-receive/10 flex items-center justify-center mb-3">
            <Check size={24} className="text-receive" />
          </div>
          <p className="font-medium text-sm">QR Code scanné !</p>
          <p className="text-xs text-muted-foreground mt-1 break-all font-mono">{scannedResult}</p>
          <div className="flex gap-2 mt-3 justify-center">
            <Button variant="outline" size="sm" className="rounded-xl" onClick={onRescan}>
              Scanner à nouveau
            </Button>
            <Button size="sm" className="rounded-xl" onClick={onSend}>
              Envoyer des fichiers
            </Button>
          </div>
        </div>
      ) : (
        <>
          <div className="bg-card p-6 rounded-2xl shadow-lg border border-border">
            <QRCodeSVG
              value={inviteUrl}
              size={180}
              bgColor="transparent"
              fgColor="hsl(250, 80%, 60%)"
              level="M"
            />
          </div>
          <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <Globe size={14} />
            <span className="font-mono">Salon {room}</span>
          </div>
          <div className="mt-3 flex items-center gap-2 bg-connect/10 text-connect px-4 py-2 rounded-full">
            <Shield size={14} />
            <span className="text-sm font-semibold tracking-widest">{statusLabel}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center max-w-[260px]">
            Scannez ce QR depuis l'autre appareil pour ouvrir un canal P2P chiffré
          </p>
          <div className="flex gap-3 mt-4">
            <Button variant="default" className="gap-2 rounded-xl" onClick={onScannerOpen}>
              <ScanLine size={16} />
              Scanner un QR
            </Button>
            <Button variant="outline" className="gap-2 rounded-xl" onClick={onPCInterface}>
              <Monitor size={16} />
              Interface PC
            </Button>
          </div>
        </>
      )}
    </motion.div>
  );
}
