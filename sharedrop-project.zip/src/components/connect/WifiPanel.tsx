import { motion } from "framer-motion";
import { Wifi, Loader2, Check } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import DeviceList from "./DeviceList";
import { getNetworkInfo, type DiscoveredDevice } from "@/lib/connect-types";

interface WifiPanelProps {
  scanning: boolean;
  devices: DiscoveredDevice[];
  connectedId: string | null;
  onRescan: () => void;
  onConnect: (device: DiscoveredDevice) => void;
}

/** Wi-Fi Direct panel — simulated discovery, real connection metadata when available. */
export default function WifiPanel({
  scanning, devices, connectedId, onRescan, onConnect,
}: WifiPanelProps) {
  const navigate = useNavigate();
  const netInfo = getNetworkInfo();

  return (
    <motion.div
      key="wifi"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="mt-6"
    >
      <div className="p-4 bg-card rounded-2xl border border-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-receive/10 flex items-center justify-center">
              <Wifi size={24} className={`text-receive ${scanning ? "animate-pulse" : ""}`} />
            </div>
            <div>
              <p className="font-medium text-sm">Wi-Fi Direct</p>
              <p className="text-xs text-muted-foreground">
                {scanning ? "Scan du réseau..." : `${devices.length} appareil(s) trouvé(s)`}
              </p>
              {netInfo && (
                <p className="text-[10px] text-muted-foreground">
                  Réseau: {netInfo.type} • {netInfo.effectiveType} • {netInfo.downlink} Mbps
                </p>
              )}
            </div>
          </div>
          <Button
            variant="outline" size="sm"
            className="h-8 rounded-lg text-xs gap-1"
            onClick={onRescan} disabled={scanning}
          >
            {scanning ? <Loader2 size={12} className="animate-spin" /> : <Wifi size={12} />}
            {scanning ? "Scan..." : "Re-scanner"}
          </Button>
        </div>
        {connectedId && (
          <div className="flex items-center justify-between p-2 rounded-lg bg-receive/5">
            <div className="flex items-center gap-2 text-xs text-receive">
              <Check size={12} /> Connecté — Prêt pour le transfert
            </div>
            <Button
              size="sm"
              className="h-7 text-xs rounded-lg bg-receive text-receive-foreground"
              onClick={() => navigate("/send")}
            >
              Envoyer
            </Button>
          </div>
        )}
      </div>
      <DeviceList
        devices={devices}
        connectedId={connectedId}
        type="wifi"
        scanning={scanning}
        onConnect={onConnect}
      />
    </motion.div>
  );
}
