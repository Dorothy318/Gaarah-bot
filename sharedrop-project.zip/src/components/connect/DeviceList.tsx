import { motion, AnimatePresence } from "framer-motion";
import { Loader2, Check, Smartphone, Laptop } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { DiscoveredDevice } from "@/lib/connect-types";

interface DeviceListProps {
  devices: DiscoveredDevice[];
  connectedId: string | null;
  type: "wifi" | "bt";
  scanning: boolean;
  onConnect: (device: DiscoveredDevice) => void;
}

// Static class maps so Tailwind can detect them at build time.
const styles = {
  wifi: {
    cardActive: "bg-receive/10 ring-2 ring-receive/30",
    iconBg: "bg-receive/10",
    iconText: "text-receive",
    badge: "text-receive bg-receive/10",
  },
  bt: {
    cardActive: "bg-connect/10 ring-2 ring-connect/30",
    iconBg: "bg-connect/10",
    iconText: "text-connect",
    badge: "text-connect bg-connect/10",
  },
} as const;

export default function DeviceList({
  devices, connectedId, type, scanning, onConnect,
}: DeviceListProps) {
  const s = styles[type];
  return (
    <div className="space-y-2 mt-4">
      {scanning && devices.length === 0 && (
        <div className="flex items-center justify-center gap-2 py-4 text-sm text-muted-foreground">
          <Loader2 size={16} className="animate-spin" />
          Recherche en cours...
        </div>
      )}
      <AnimatePresence>
        {devices.map((device, i) => {
          const Icon = device.type === "phone" ? Smartphone : Laptop;
          const isConnected = connectedId === device.id;
          return (
            <motion.div
              key={device.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              onClick={() => !isConnected && onConnect(device)}
              className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all ${
                isConnected ? s.cardActive : "bg-card hover:bg-secondary"
              }`}
            >
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${s.iconBg}`}>
                <Icon size={18} className={s.iconText} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{device.name}</p>
                <div className="flex items-center gap-2">
                  <p className="text-xs text-muted-foreground">Signal : {device.signal}</p>
                  {device.ip && (
                    <span className="text-[10px] text-muted-foreground font-mono">{device.ip}</span>
                  )}
                </div>
              </div>
              {isConnected ? (
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${s.badge}`}>
                  <Check size={12} className="inline mr-1" />
                  Connecté
                </span>
              ) : (
                <Button variant="outline" size="sm" className="h-7 text-xs rounded-lg">
                  Connecter
                </Button>
              )}
            </motion.div>
          );
        })}
      </AnimatePresence>
      {scanning && devices.length > 0 && (
        <p className="text-xs text-muted-foreground text-center mt-2 flex items-center justify-center gap-1">
          <Loader2 size={12} className="animate-spin" /> Recherche...
        </p>
      )}
    </div>
  );
}
