import { motion } from "framer-motion";
import { Bluetooth, Loader2, Check, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import DeviceList from "./DeviceList";
import type { DiscoveredDevice } from "@/lib/connect-types";

interface BluetoothPanelProps {
  scanning: boolean;
  devices: DiscoveredDevice[];
  connectedId: string | null;
  onRescan: () => void;
  onConnect: (device: DiscoveredDevice) => void;
}

export default function BluetoothPanel({
  scanning, devices, connectedId, onRescan, onConnect,
}: BluetoothPanelProps) {
  const navigate = useNavigate();
  return (
    <motion.div
      key="bt"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="mt-6"
    >
      <div className="p-4 bg-card rounded-2xl border border-border">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-connect/10 flex items-center justify-center">
              <Bluetooth size={24} className={`text-connect ${scanning ? "animate-pulse" : ""}`} />
            </div>
            <div>
              <p className="font-medium text-sm">Bluetooth</p>
              <p className="text-xs text-muted-foreground">
                {scanning ? "Recherche..." : `${devices.length} appareil(s) trouvé(s)`}
              </p>
            </div>
          </div>
          <Button
            variant="outline" size="sm"
            className="h-8 rounded-lg text-xs gap-1"
            onClick={onRescan} disabled={scanning}
          >
            {scanning ? <Loader2 size={12} className="animate-spin" /> : <Bluetooth size={12} />}
            {scanning ? "Scan..." : "Re-scanner"}
          </Button>
        </div>
        {connectedId && (
          <div className="flex items-center justify-between p-2 rounded-lg bg-connect/5">
            <div className="flex items-center gap-2 text-xs text-connect">
              <Check size={12} /> Connecté via Bluetooth
            </div>
            <Button
              size="sm"
              className="h-7 text-xs rounded-lg bg-connect text-white"
              onClick={() => navigate("/send")}
            >
              Envoyer
            </Button>
          </div>
        )}
        <div className="flex items-center gap-2 mt-2 p-2 rounded-lg bg-destructive/5 text-xs text-muted-foreground">
          <AlertCircle size={12} className="text-destructive shrink-0" />
          Vitesse réduite — utilisez Wi-Fi si possible
        </div>
      </div>
      <DeviceList
        devices={devices}
        connectedId={connectedId}
        type="bt"
        scanning={scanning}
        onConnect={onConnect}
      />
    </motion.div>
  );
}
