import { motion } from "framer-motion";
import {
  Clock, Trash2, Smartphone, Laptop, Loader2, Zap,
  Wifi, Bluetooth, QrCode,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import type { ConnectionHistoryEntry } from "@/lib/connect-types";

interface ConnectionHistoryPanelProps {
  history: ConnectionHistoryEntry[];
  reconnectingId: string | null;
  onClear: () => void;
  onReconnect: (entry: ConnectionHistoryEntry) => void;
}

const methodIcons = { wifi: Wifi, bt: Bluetooth, qr: QrCode } as const;
const methodColors = { wifi: "text-receive", bt: "text-connect", qr: "text-primary" } as const;

export default function ConnectionHistoryPanel({
  history, reconnectingId, onClear, onReconnect,
}: ConnectionHistoryPanelProps) {
  if (history.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="mt-8"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Clock size={14} className="text-muted-foreground" />
          <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
            Connexions récentes
          </span>
        </div>
        <button onClick={onClear} className="text-xs text-destructive flex items-center gap-1">
          <Trash2 size={12} /> Effacer
        </button>
      </div>
      <div className="space-y-2">
        {history.map((entry, i) => {
          const MethodIcon = methodIcons[entry.method];
          const DeviceIcon = entry.type === "phone" ? Smartphone : Laptop;
          const isReconnecting = reconnectingId === entry.id;
          return (
            <motion.div
              key={entry.id}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-center gap-3 p-3 rounded-xl bg-card"
            >
              <div className="w-9 h-9 rounded-lg bg-secondary flex items-center justify-center">
                <DeviceIcon size={16} className="text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{entry.name}</p>
                <div className="flex items-center gap-2">
                  <p className="text-xs text-muted-foreground">{entry.time}</p>
                  <div className={`flex items-center gap-1 text-[10px] ${methodColors[entry.method]}`}>
                    <MethodIcon size={10} />
                    {entry.method === "wifi" ? "Wi-Fi" : entry.method === "bt" ? "BT" : "QR"}
                  </div>
                </div>
              </div>
              <Button
                variant="outline" size="sm"
                className="h-8 text-xs rounded-lg gap-1.5"
                disabled={isReconnecting}
                onClick={() => onReconnect(entry)}
              >
                {isReconnecting ? <Loader2 size={12} className="animate-spin" /> : <Zap size={12} />}
                {isReconnecting ? "..." : "Reconnecter"}
              </Button>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
