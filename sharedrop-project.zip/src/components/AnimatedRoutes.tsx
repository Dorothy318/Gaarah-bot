import { lazy, Suspense } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import PageTransition from "./PageTransition";

const HomePage = lazy(() => import("@/pages/HomePage"));
const SendScreen = lazy(() => import("@/pages/SendScreen"));
const ReceiveScreen = lazy(() => import("@/pages/ReceiveScreen"));
const ConnectScreen = lazy(() => import("@/pages/ConnectScreen"));
const TransferScreen = lazy(() => import("@/pages/TransferScreen"));
const QRScanScreen = lazy(() => import("@/pages/QRScanScreen"));
const FileExplorerScreen = lazy(() => import("@/pages/FileExplorerScreen"));
const HistoryScreen = lazy(() => import("@/pages/HistoryScreen"));
const SettingsScreen = lazy(() => import("@/pages/SettingsScreen"));
const DiagnosticsScreen = lazy(() => import("@/pages/DiagnosticsScreen"));
const NotFound = lazy(() => import("@/pages/NotFound"));
const AuthScreen = lazy(() => import("@/pages/AuthScreen"));

const pages = [
  { path: "/", element: <HomePage /> },
  { path: "/send", element: <SendScreen /> },
  { path: "/receive", element: <ReceiveScreen /> },
  { path: "/connect", element: <ConnectScreen /> },
  { path: "/transfer", element: <TransferScreen /> },
  { path: "/qr-scan", element: <QRScanScreen /> },
  { path: "/explorer", element: <FileExplorerScreen /> },
  { path: "/history", element: <HistoryScreen /> },
  { path: "/settings", element: <SettingsScreen /> },
  { path: "/diagnostics", element: <DiagnosticsScreen /> },
  { path: "/auth", element: <AuthScreen /> },
  { path: "*", element: <NotFound /> },
];

function RouteFallback() {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="flex items-center justify-center min-h-[60vh]"
      role="status"
      aria-live="polite"
    >
      <Loader2 className="text-primary animate-spin" size={28} />
      <span className="sr-only">Chargement…</span>
    </motion.div>
  );
}

export default function AnimatedRoutes() {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Suspense fallback={<RouteFallback />}>
        <Routes location={location} key={location.pathname}>
          {pages.map(({ path, element }) => (
            <Route
              key={path}
              path={path}
              element={<PageTransition>{element}</PageTransition>}
            />
          ))}
        </Routes>
      </Suspense>
    </AnimatePresence>
  );
}
