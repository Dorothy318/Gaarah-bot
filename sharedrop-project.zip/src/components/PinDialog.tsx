import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PinDialogProps {
  deviceName: string;
  pin: string;
  open: boolean;
  onAccept: () => void;
  onReject: () => void;
}

export default function PinDialog({ deviceName, pin, open, onAccept, onReject }: PinDialogProps) {
  const [inputPin, setInputPin] = useState(["", "", "", ""]);
  const [error, setError] = useState(false);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (open) {
      setInputPin(["", "", "", ""]);
      setError(false);
      setTimeout(() => inputRefs.current[0]?.focus(), 100);
    }
  }, [open]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;
    const newPin = [...inputPin];
    newPin[index] = value;
    setInputPin(newPin);
    setError(false);

    if (value && index < 3) {
      inputRefs.current[index + 1]?.focus();
    }

    if (index === 3 && value) {
      const entered = newPin.join("");
      if (entered === pin) {
        onAccept();
      } else {
        setError(true);
        setTimeout(() => {
          setInputPin(["", "", "", ""]);
          inputRefs.current[0]?.focus();
        }, 600);
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !inputPin[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-5"
        >
          <motion.div
            initial={{ scale: 0.9, y: 20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="bg-card rounded-3xl p-6 w-full max-w-sm border border-border shadow-xl"
          >
            {/* Close */}
            <div className="flex justify-end">
              <button onClick={onReject} className="text-muted-foreground hover:text-foreground">
                <X size={20} />
              </button>
            </div>

            {/* Icon */}
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center">
                <Shield size={32} className="text-primary" />
              </div>
            </div>

            {/* Info */}
            <h2 className="text-lg font-bold font-heading text-center">Demande de connexion</h2>
            <p className="text-sm text-muted-foreground text-center mt-1 mb-1">
              <span className="font-semibold text-foreground">{deviceName}</span> souhaite se connecter
            </p>
            <p className="text-xs text-muted-foreground text-center mb-6">
              Entrez le code PIN affiché sur l'autre appareil
            </p>

            {/* PIN input */}
            <div className="flex justify-center gap-3 mb-6">
              {inputPin.map((digit, i) => (
                <motion.input
                  key={i}
                  ref={(el) => { inputRefs.current[i] = el; }}
                  type="text"
                  inputMode="numeric"
                  maxLength={1}
                  value={digit}
                  onChange={(e) => handleChange(i, e.target.value)}
                  onKeyDown={(e) => handleKeyDown(i, e)}
                  animate={error ? { x: [0, -8, 8, -8, 8, 0] } : {}}
                  transition={{ duration: 0.4 }}
                  className={`w-14 h-14 rounded-xl text-center text-2xl font-bold border-2 bg-background outline-none transition-colors ${
                    error
                      ? "border-destructive text-destructive"
                      : digit
                      ? "border-primary text-foreground"
                      : "border-border text-foreground"
                  } focus:border-primary`}
                />
              ))}
            </div>

            {error && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-xs text-destructive text-center mb-4"
              >
                Code incorrect, réessayez
              </motion.p>
            )}

            {/* Actions */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={onReject}
                className="flex-1 h-12 rounded-xl"
              >
                Refuser
              </Button>
              <Button
                onClick={onAccept}
                disabled={inputPin.join("").length < 4}
                className="flex-1 h-12 rounded-xl bg-primary text-primary-foreground"
              >
                Accepter
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
