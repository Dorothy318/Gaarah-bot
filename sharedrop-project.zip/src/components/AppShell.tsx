import { ReactNode } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Home, Send, Download, Wifi, Clock, Settings, FolderOpen } from "lucide-react";
import { motion } from "framer-motion";

const tabs = [
  { path: "/", icon: Home, label: "Accueil" },
  { path: "/send", icon: Send, label: "Envoyer" },
  { path: "/receive", icon: Download, label: "Recevoir" },
  { path: "/connect", icon: Wifi, label: "Connecter" },
  { path: "/explorer", icon: FolderOpen, label: "Fichiers" },
  { path: "/history", icon: Clock, label: "Historique" },
  { path: "/settings", icon: Settings, label: "Réglages" },
];

export default function AppShell({ children }: { children: ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const hideNav = ["/transfer", "/qr-scan", "/auth"].includes(location.pathname);

  return (
    <div className="min-h-screen bg-background flex flex-col max-w-md mx-auto relative">
      <div className="flex-1 overflow-y-auto pb-20">
        {children}
      </div>
      {!hideNav && (
        <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-card/80 backdrop-blur-xl border-t border-border z-40">
          <div className="flex justify-around items-center py-2">
            {tabs.map((tab) => {
              const active = location.pathname === tab.path;
              return (
                <button
                  key={tab.path}
                  onClick={() => navigate(tab.path)}
                  className="flex flex-col items-center gap-0.5 px-2 py-1 relative"
                >
                  {active && (
                    <motion.div
                      layoutId="tab-indicator"
                      className="absolute -top-2 w-8 h-1 rounded-full bg-primary"
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                    />
                  )}
                  <tab.icon
                    size={18}
                    className={active ? "text-primary" : "text-muted-foreground"}
                  />
                  <span
                    className={`text-[9px] font-medium ${
                      active ? "text-primary" : "text-muted-foreground"
                    }`}
                  >
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>
        </nav>
      )}
    </div>
  );
}
