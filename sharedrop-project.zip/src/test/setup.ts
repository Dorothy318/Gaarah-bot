import "@testing-library/jest-dom";

Object.defineProperty(window, "matchMedia", {
  writable: true,
  value: (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => {},
  }),
});

// jsdom's Blob lacks arrayBuffer() / text(). Polyfill via FileReader so file-transfer
// and SHA-256 tests can run in node + jsdom.
function definePolyfill(name: "arrayBuffer" | "text", impl: (b: Blob) => Promise<unknown>) {
  if (typeof Blob === "undefined") return;
  const proto = Blob.prototype as unknown as Record<string, unknown>;
  if (typeof proto[name] === "function") return;
  Object.defineProperty(Blob.prototype, name, {
    configurable: true,
    writable: true,
    value(this: Blob) { return impl(this); },
  });
}

definePolyfill("arrayBuffer", (blob) =>
  new Promise<ArrayBuffer>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as ArrayBuffer);
    reader.onerror = () => reject(reader.error);
    reader.readAsArrayBuffer(blob);
  }),
);
definePolyfill("text", (blob) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(reader.error);
    reader.readAsText(blob);
  }),
);

