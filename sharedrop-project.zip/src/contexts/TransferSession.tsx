/**
 * TransferSession — application-wide WebRTC session shared by Send / Receive /
 * Connect / Transfer screens.
 *
 * Responsibilities:
 *  - Owns a single RTCPeerConnection + DataChannel that survives route changes.
 *  - Signaling via hardened Supabase Realtime (see webrtc-signaling.ts).
 *  - Host side: consumes a queue of `File` objects and sends them with
 *    `sendFile()` from file-transfer.ts (chunking, backpressure, SHA-256).
 *  - Guest side: feeds inbound data channel messages into `createReceiver()`
 *    and exposes assembled blobs (auto-downloaded on completion).
 *  - Publishes reactive state:
 *      role, phase, transfers Map, receivedFiles, error.
 */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { toast } from "sonner";
import {
  getDefaultIceServers,
  joinSignalingRoom,
  type SignalingClient,
  type SignalMessage,
  type SignalRole,
} from "@/lib/webrtc-signaling";
import {
  sendFile,
  createReceiver,
  type ReceivedFile,
} from "@/lib/file-transfer";
import { reportError } from "@/lib/reporter";
import { notifyIfBackground } from "@/lib/notifications";

/* ── Types ────────────────────────────────────────────────────────────── */

export type SessionPhase =
  | "idle"
  | "joining"
  | "waiting"
  | "connecting"
  | "connected"
  | "transferring"
  | "done"
  | "failed"
  | "disconnected";

export interface TransferItem {
  id: string;
  name: string;
  size: number;
  mime: string;
  direction: "send" | "receive";
  bytesTransferred: number;
  percent: number;
  status: "queued" | "active" | "done" | "error";
  error?: string;
  /** Populated on the receive side once fully assembled. */
  blob?: Blob;
  integrityOk?: boolean;
}

interface TransferSessionValue {
  phase: SessionPhase;
  role: SignalRole | null;
  remotePeerId: string | null;
  error: string | null;
  transfers: TransferItem[];
  receivedFiles: TransferItem[];
  pendingCount: number;

  /** Host: create room, wait for guest, then send queued files. */
  startAsHost: (room: string, token: string) => Promise<void>;
  /** Guest: join an existing room. */
  startAsGuest: (room: string, token: string) => Promise<void>;

  /** Queue files to be sent as soon as the channel is open. Host only. */
  queueFiles: (files: File[]) => void;

  /** Tear the session down. */
  reset: () => Promise<void>;
}

const Ctx = createContext<TransferSessionValue | null>(null);

/* ── Provider ─────────────────────────────────────────────────────────── */

export function TransferSessionProvider({ children }: { children: ReactNode }) {
  const [phase, setPhase] = useState<SessionPhase>("idle");
  const [role, setRole] = useState<SignalRole | null>(null);
  const [remotePeerId, setRemotePeerId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [transfers, setTransfers] = useState<TransferItem[]>([]);
  const [pendingCount, setPendingCount] = useState(0);

  // Refs that don't need to trigger re-renders
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const dcRef = useRef<RTCDataChannel | null>(null);
  const sigRef = useRef<SignalingClient | null>(null);
  const roleRef = useRef<SignalRole | null>(null);
  const remoteIdRef = useRef<string | null>(null);
  const queueRef = useRef<File[]>([]);
  const sendingRef = useRef(false);
  const receiverRef = useRef<ReturnType<typeof createReceiver> | null>(null);
  const doneNotifiedRef = useRef(false);

  const upsertTransfer = useCallback(
    (id: string, patch: Partial<TransferItem>, defaults?: Partial<TransferItem>) => {
      setTransfers((prev) => {
        const idx = prev.findIndex((t) => t.id === id);
        if (idx === -1) {
          const created: TransferItem = {
            id,
            name: defaults?.name ?? "file",
            size: defaults?.size ?? 0,
            mime: defaults?.mime ?? "application/octet-stream",
            direction: defaults?.direction ?? "send",
            bytesTransferred: 0,
            percent: 0,
            status: "queued",
            ...defaults,
            ...patch,
          };
          return [...prev, created];
        }
        const next = [...prev];
        next[idx] = { ...next[idx], ...patch };
        return next;
      });
    },
    [],
  );

  const cleanup = useCallback(async () => {
    try { dcRef.current?.close(); } catch { /* ignore */ }
    try { pcRef.current?.close(); } catch { /* ignore */ }
    try { await sigRef.current?.close(); } catch { /* ignore */ }
    dcRef.current = null;
    pcRef.current = null;
    sigRef.current = null;
    remoteIdRef.current = null;
    receiverRef.current?.reset();
    receiverRef.current = null;
    sendingRef.current = false;
    setRemotePeerId(null);
  }, []);

  const reset = useCallback(async () => {
    await cleanup();
    queueRef.current = [];
    setPendingCount(0);
    setTransfers([]);
    setRole(null);
    setError(null);
    setPhase("idle");
    doneNotifiedRef.current = false;
  }, [cleanup]);

  // Automatic cleanup on unmount (usually app-level, but safe)
  useEffect(() => () => { void cleanup(); }, [cleanup]);

  /* ── Sending loop ─────────────────────────────────────────────────── */

  const runSendQueue = useCallback(async () => {
    if (sendingRef.current) return;
    const dc = dcRef.current;
    if (!dc || dc.readyState !== "open") return;
    if (queueRef.current.length === 0) return;

    sendingRef.current = true;
    setPhase("transferring");

    while (queueRef.current.length > 0) {
      const file = queueRef.current.shift()!;
      setPendingCount(queueRef.current.length);
      const id = crypto.randomUUID();
      upsertTransfer(id, { status: "active" }, {
        name: file.name,
        size: file.size,
        mime: file.type || "application/octet-stream",
        direction: "send",
      });

      try {
        await sendFile(dc, file, {
          onProgress: (p) => {
            upsertTransfer(id, {
              bytesTransferred: p.bytesSent,
              percent: p.percent,
            });
          },
        });
        upsertTransfer(id, { status: "done", percent: 100 });
      } catch (err) {
        const message = err instanceof Error ? err.message : "Envoi échoué";
        upsertTransfer(id, { status: "error", error: message });
        reportError(err, { phase: "send", file: file.name });
        toast.error(`Échec envoi ${file.name}`, { description: message });
      }
    }

    sendingRef.current = false;
    setPhase((prev) => (prev === "transferring" ? "done" : prev));
    if (!doneNotifiedRef.current) {
      doneNotifiedRef.current = true;
      notifyIfBackground("Transfert terminé", "Tous les fichiers ont été envoyés.");
    }
  }, [upsertTransfer]);

  /* ── Signaling / RTCPeer plumbing ─────────────────────────────────── */

  const attachChannel = useCallback((channel: RTCDataChannel) => {
    dcRef.current = channel;
    channel.binaryType = "arraybuffer";

    // Receiver hooks up on every channel (host too — supports bidirectional later).
    if (!receiverRef.current) {
      receiverRef.current = createReceiver({
        onProgress: (id, p) => {
          upsertTransfer(id, {
            bytesTransferred: p.bytesSent,
            percent: p.percent,
            status: p.percent >= 100 ? "done" : "active",
          });
        },
        onFile: (rf: ReceivedFile) => {
          upsertTransfer(rf.header.id, {
            status: rf.integrityOk ? "done" : "error",
            error: rf.integrityOk ? undefined : "Intégrité invalide",
            blob: rf.blob,
            integrityOk: rf.integrityOk,
            percent: 100,
          }, {
            name: rf.header.name,
            size: rf.header.size,
            mime: rf.header.mime,
            direction: "receive",
          });

          // Auto-download for the guest UX
          try {
            const url = URL.createObjectURL(rf.blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = rf.header.name;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 30_000);
          } catch { /* ignore */ }

          toast.success(`Reçu : ${rf.header.name}`);
          if (!doneNotifiedRef.current) {
            doneNotifiedRef.current = true;
            notifyIfBackground("Fichier reçu", rf.header.name);
          }
        },
        onError: (err) => {
          reportError(err, { phase: "receive" });
          toast.error(err.message);
        },
      });
    }

    channel.onopen = () => {
      setPhase("connected");
      if (roleRef.current === "host") void runSendQueue();
    };
    channel.onclose = () => setPhase("disconnected");
    channel.onerror = () => setPhase("failed");
    channel.onmessage = (e) => receiverRef.current?.handle(e.data);
  }, [runSendQueue, upsertTransfer]);

  const handleSignal = useCallback(async (msg: SignalMessage) => {
    const pc = pcRef.current;
    const sig = sigRef.current;
    if (!pc || !sig) return;
    if (msg.fromRole === sig.role) return;

    switch (msg.type) {
      case "hello": {
        if (sig.role === "host" && !remoteIdRef.current) {
          remoteIdRef.current = msg.from;
          setRemotePeerId(msg.from);
          setPhase("connecting");
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          await sig.send({ type: "offer", to: msg.from, sdp: offer });
        } else if (sig.role === "guest" && !remoteIdRef.current) {
          remoteIdRef.current = msg.from;
          setRemotePeerId(msg.from);
          setPhase("connecting");
        }
        break;
      }
      case "offer": {
        if (msg.to !== sig.peerId || sig.role !== "guest") return;
        if (!remoteIdRef.current) remoteIdRef.current = msg.from;
        else if (remoteIdRef.current !== msg.from) return;
        setRemotePeerId(msg.from);
        setPhase("connecting");
        await pc.setRemoteDescription(msg.sdp);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await sig.send({ type: "answer", to: msg.from, sdp: answer });
        break;
      }
      case "answer": {
        if (msg.to !== sig.peerId || sig.role !== "host") return;
        if (remoteIdRef.current && remoteIdRef.current !== msg.from) return;
        await pc.setRemoteDescription(msg.sdp);
        break;
      }
      case "ice": {
        if (msg.to !== sig.peerId) return;
        if (!remoteIdRef.current || remoteIdRef.current !== msg.from) return;
        try { await pc.addIceCandidate(msg.candidate); }
        catch (err) { console.warn("addIceCandidate failed", err); }
        break;
      }
      case "bye": {
        if (msg.from === remoteIdRef.current) setPhase("disconnected");
        break;
      }
    }
  }, []);

  const start = useCallback(async (room: string, token: string, r: SignalRole) => {
    await cleanup();
    setError(null);
    setRole(r);
    roleRef.current = r;
    setPhase("joining");
    doneNotifiedRef.current = false;

    try {
      const pc = new RTCPeerConnection({ iceServers: getDefaultIceServers() });
      pcRef.current = pc;

      pc.onconnectionstatechange = () => {
        const s = pc.connectionState;
        if (s === "failed") {
          setPhase("failed");
          reportError(new Error("RTCPeerConnection failed"), { phase: "ice" });
        } else if (s === "disconnected") setPhase((prev) =>
          prev === "transferring" ? prev : "disconnected"
        );
      };

      pc.ondatachannel = (e) => attachChannel(e.channel);

      const sig = await joinSignalingRoom(room, token, r, { requireSession: false });
      sigRef.current = sig;

      pc.onicecandidate = (e) => {
        if (e.candidate && remoteIdRef.current && sigRef.current) {
          void sigRef.current.send({
            type: "ice",
            to: remoteIdRef.current,
            candidate: e.candidate.toJSON(),
          });
        }
      };

      sig.onMessage((m) => { void handleSignal(m); });

      if (r === "host") {
        const dc = pc.createDataChannel("files", { ordered: true });
        attachChannel(dc);
      }

      setPhase("waiting");
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erreur inconnue";
      setError(message);
      setPhase("failed");
      toast.error("Échec connexion signaling", { description: message });
      reportError(err, { phase: "start", role: r });
      await cleanup();
    }
  }, [attachChannel, cleanup, handleSignal]);

  const startAsHost = useCallback((room: string, token: string) => start(room, token, "host"), [start]);
  const startAsGuest = useCallback((room: string, token: string) => start(room, token, "guest"), [start]);

  const queueFiles = useCallback((files: File[]) => {
    queueRef.current.push(...files);
    setPendingCount(queueRef.current.length);
    if (dcRef.current?.readyState === "open" && roleRef.current === "host") {
      void runSendQueue();
    }
  }, [runSendQueue]);

  const value = useMemo<TransferSessionValue>(() => ({
    phase,
    role,
    remotePeerId,
    error,
    transfers,
    receivedFiles: transfers.filter((t) => t.direction === "receive"),
    pendingCount,
    startAsHost,
    startAsGuest,
    queueFiles,
    reset,
  }), [phase, role, remotePeerId, error, transfers, pendingCount, startAsHost, startAsGuest, queueFiles, reset]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useTransferSession(): TransferSessionValue {
  const v = useContext(Ctx);
  if (!v) throw new Error("useTransferSession must be used within TransferSessionProvider");
  return v;
}
