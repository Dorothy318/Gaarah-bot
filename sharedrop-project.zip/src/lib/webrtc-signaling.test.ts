import { describe, it, expect } from "vitest";
import {
  generateRoomCode,
  generateRoomToken,
  encodeRoomInvite,
  decodeRoomInvite,
} from "@/lib/webrtc-signaling";

describe("room codes & tokens", () => {
  it("generates uppercase alphanum room codes of correct length", () => {
    for (let i = 0; i < 20; i++) {
      const c = generateRoomCode(6);
      expect(c).toMatch(/^[A-Z0-9]{6}$/);
      // Confusing chars must be excluded.
      expect(c).not.toMatch(/[IO01]/);
    }
  });

  it("generates 24-char tokens", () => {
    const t = generateRoomToken();
    expect(t).toMatch(/^[A-Z0-9]{24}$/);
  });
});

describe("invite encode/decode", () => {
  it("roundtrips room + token", () => {
    const room = "K7F2QX";
    const token = generateRoomToken();
    const url = encodeRoomInvite(room, token);
    expect(url.startsWith("sharedrop://v1/join")).toBe(true);
    const parsed = decodeRoomInvite(url);
    expect(parsed).toEqual({ room, token });
  });

  it("rejects non-sharedrop URLs", () => {
    expect(decodeRoomInvite("https://evil.example/join?r=AAAA&t=BBBBBBBBBBBBBBBB")).toBeNull();
  });

  it("rejects malformed payloads", () => {
    expect(decodeRoomInvite("not a url")).toBeNull();
    expect(decodeRoomInvite("sharedrop://v1/join?r=AB")).toBeNull();
    expect(decodeRoomInvite("sharedrop://v1/join?r=ABCD")).toBeNull(); // missing token
    expect(decodeRoomInvite("sharedrop://v1/join?r=lowercase&t=BBBBBBBBBBBBBBBB")).toBeNull();
  });
});
