import { describe, it, expect } from "vitest";
import {
  connectReducer,
  initialConnectStatus,
  describeConnectStatus,
} from "@/lib/connect-machine";

describe("connectReducer", () => {
  it("starts idle", () => {
    expect(initialConnectStatus.kind).toBe("idle");
  });

  it("selects a method", () => {
    const next = connectReducer(initialConnectStatus, { type: "SELECT_METHOD", method: "wifi" });
    expect(next).toEqual({ kind: "method-selected", method: "wifi" });
  });

  it("handles a full wifi scan flow", () => {
    let s = connectReducer(initialConnectStatus, { type: "SELECT_METHOD", method: "wifi" });
    s = connectReducer(s, { type: "START_SCAN", method: "wifi" });
    expect(s.kind).toBe("scanning");
    s = connectReducer(s, { type: "SCAN_RESULT", method: "wifi", count: 2 });
    expect(s).toEqual({ kind: "devices-found", method: "wifi", count: 2 });
    s = connectReducer(s, { type: "CONNECT_DEVICE", method: "wifi", deviceId: "x" });
    expect(s.kind).toBe("connecting");
    s = connectReducer(s, { type: "CONNECTED", method: "wifi", deviceId: "x" });
    expect(s).toEqual({ kind: "connected", method: "wifi", deviceId: "x" });
  });

  it("disconnect from connected returns to method-selected", () => {
    const s = connectReducer(
      { kind: "connected", method: "qr" },
      { type: "DISCONNECT" },
    );
    expect(s).toEqual({ kind: "method-selected", method: "qr" });
  });

  it("FAIL transitions to failed regardless of state", () => {
    const s = connectReducer(initialConnectStatus, {
      type: "FAIL", method: "qr", reason: "timeout",
    });
    expect(s).toEqual({ kind: "failed", method: "qr", reason: "timeout" });
  });

  it("RESET goes back to idle", () => {
    const s = connectReducer(
      { kind: "connected", method: "wifi" },
      { type: "RESET" },
    );
    expect(s.kind).toBe("idle");
  });

  it("unknown event preserves state", () => {
    const s = connectReducer(
      { kind: "scanning", method: "bt" },
      // @ts-expect-error testing unknown event
      { type: "NOPE" },
    );
    expect(s).toEqual({ kind: "scanning", method: "bt" });
  });
});

describe("describeConnectStatus", () => {
  it("produces a French label", () => {
    expect(describeConnectStatus({ kind: "scanning", method: "wifi" })).toMatch(/Recherche/);
    expect(describeConnectStatus({ kind: "connected", method: "qr" })).toBe("Connecté");
    expect(describeConnectStatus({ kind: "failed", method: "wifi", reason: "x" })).toContain("x");
  });
});
