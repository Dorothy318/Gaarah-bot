/**
 * Browser notifications helper for background transfer completion.
 * Requests permission once, persists user preference in localStorage,
 * and gracefully degrades when the API is unavailable.
 */

const STORAGE_KEY = "sharedrop_notifications_enabled";

export function notificationsSupported(): boolean {
  return typeof window !== "undefined" && "Notification" in window;
}

export function notificationsEnabled(): boolean {
  if (!notificationsSupported()) return false;
  if (Notification.permission !== "granted") return false;
  return localStorage.getItem(STORAGE_KEY) === "true";
}

export function notificationsPermission(): NotificationPermission | "unsupported" {
  if (!notificationsSupported()) return "unsupported";
  return Notification.permission;
}

export async function requestNotifications(): Promise<boolean> {
  if (!notificationsSupported()) return false;
  let permission = Notification.permission;
  if (permission === "default") {
    try {
      permission = await Notification.requestPermission();
    } catch {
      return false;
    }
  }
  const granted = permission === "granted";
  localStorage.setItem(STORAGE_KEY, granted ? "true" : "false");
  return granted;
}

export function disableNotifications(): void {
  localStorage.setItem(STORAGE_KEY, "false");
}

/**
 * Show a notification only when the page is hidden (true background).
 * In foreground we let the in-app toast handle it to avoid double UX.
 */
export function notifyIfBackground(title: string, body?: string): void {
  if (!notificationsEnabled()) return;
  if (typeof document !== "undefined" && document.visibilityState === "visible") return;
  try {
    new Notification(title, {
      body,
      icon: "/icons/icon-192.png",
      badge: "/icons/icon-192.png",
      tag: "sharedrop-transfer",
    });
  } catch {
    /* ignore */
  }
}
