/**
 * WebRTC connectivity diagnostics.
 *
 * Spawns a temporary RTCPeerConnection, triggers ICE gathering on a dummy
 * data channel, and inspects the candidates that come back to determine:
 *
 *  - whether STUN reflexive candidates are reachable (NAT traversal viable),
 *  - whether TURN relay candidates are reachable (firewall fallback works),
 *  - latency until the first useful candidate is gathered,
 *  - and which transport mode is realistically available.
 *
 * Pure function — no UI, easy to unit-test or call from any screen.
 */

import { getDefaultIceServers, hasTurnConfigured } from "./webrtc-signaling";

export type DiagMode = "host" | "stun" | "turn" | "blocked";

export interface CandidateSample {
  type: "host" | "srflx" | "prflx" | "relay";
  protocol?: string;
  address?: string;
  ms: number;
}

export interface DiagnosticsResult {
  startedAt: number;
  durationMs: number;
  mode: DiagMode;
  hasStun: boolean;
  hasTurn: boolean;
  turnConfigured: boolean;
  firstCandidateMs: number | null;
  firstSrflxMs: number | null;
  firstRelayMs: number | null;
  candidates: CandidateSample[];
  errors: string[];
}

const DEFAULT_TIMEOUT_MS = 8_000;

function classifyMode(r: Omit<DiagnosticsResult, "mode">): DiagMode {
  if (r.hasTurn) return "turn";
  if (r.hasStun) return "stun";
  if (r.candidates.some((c) => c.type === "host")) return "host";
  return "blocked";
}

export async function runWebRTCDiagnostics(
  options: { timeoutMs?: number; iceServers?: RTCIceServer[] } = {},
): Promise<DiagnosticsResult> {
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const iceServers = options.iceServers ?? getDefaultIceServers();
  const turnConfigured = hasTurnConfigured();

  const startedAt = Date.now();
  const t0 = performance.now();
  const candidates: CandidateSample[] = [];
  const errors: string[] = [];
  let firstCandidateMs: number | null = null;
  let firstSrflxMs: number | null = null;
  let firstRelayMs: number | null = null;
  let hasStun = false;
  let hasTurn = false;

  let pc: RTCPeerConnection | null = null;

  try {
    pc = new RTCPeerConnection({ iceServers, iceCandidatePoolSize: 0 });
    // Data channel is needed on some browsers to actually trigger ICE gathering.
    pc.createDataChannel("diag");

    const done = new Promise<void>((resolve) => {
      const timer = setTimeout(() => resolve(), timeoutMs);

      pc!.onicecandidate = (ev) => {
        if (!ev.candidate || !ev.candidate.candidate) {
          // null candidate => gathering complete
          clearTimeout(timer);
          resolve();
          return;
        }
        const ms = Math.round(performance.now() - t0);
        const c = ev.candidate;
        const type = (c.type ?? "host") as CandidateSample["type"];
        candidates.push({
          type,
          protocol: c.protocol ?? undefined,
          address: c.address ?? undefined,
          ms,
        });
        if (firstCandidateMs === null) firstCandidateMs = ms;
        if (type === "srflx" && firstSrflxMs === null) {
          firstSrflxMs = ms;
          hasStun = true;
        }
        if (type === "relay" && firstRelayMs === null) {
          firstRelayMs = ms;
          hasTurn = true;
        }
      };

      pc!.onicegatheringstatechange = () => {
        if (pc!.iceGatheringState === "complete") {
          clearTimeout(timer);
          resolve();
        }
      };
    });

    const offer = await pc.createOffer({
      offerToReceiveAudio: false,
      offerToReceiveVideo: false,
    });
    await pc.setLocalDescription(offer);

    await done;
  } catch (e) {
    errors.push(e instanceof Error ? e.message : String(e));
  } finally {
    try { pc?.close(); } catch { /* noop */ }
  }

  const partial = {
    startedAt,
    durationMs: Math.round(performance.now() - t0),
    hasStun,
    hasTurn,
    turnConfigured,
    firstCandidateMs,
    firstSrflxMs,
    firstRelayMs,
    candidates,
    errors,
  };

  return { ...partial, mode: classifyMode(partial) };
}

export function describeMode(mode: DiagMode): { label: string; tone: "success" | "warning" | "error" } {
  switch (mode) {
    case "turn":
      return { label: "Relais TURN disponible", tone: "success" };
    case "stun":
      return { label: "STUN OK (P2P direct)", tone: "success" };
    case "host":
      return { label: "Réseau local seulement", tone: "warning" };
    case "blocked":
      return { label: "Connectivité bloquée", tone: "error" };
  }
}
