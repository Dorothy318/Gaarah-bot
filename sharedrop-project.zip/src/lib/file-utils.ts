/**
 * Shared file utilities used across SendScreen, TransferScreen, HistoryScreen
 * and the WebRTC transfer layer. Pure functions only — easy to unit test.
 */

import { Image, Video, FileText, Package, File, type LucideIcon } from "lucide-react";

export type FileKind = "image" | "video" | "document" | "apk" | "other";

const KB = 1024;
const MB = KB * 1024;
const GB = MB * 1024;

/** Human-readable byte size (e.g. "1.4 MB"). */
export function formatSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return "—";
  if (bytes < KB) return `${bytes} B`;
  if (bytes < MB) return `${(bytes / KB).toFixed(1)} KB`;
  if (bytes < GB) return `${(bytes / MB).toFixed(1)} MB`;
  return `${(bytes / GB).toFixed(2)} GB`;
}

/** Bytes-per-second to human readable speed (e.g. "2.3 MB/s"). */
export function formatSpeed(bytesPerSec: number): string {
  if (!Number.isFinite(bytesPerSec) || bytesPerSec <= 0) return "—";
  return `${formatSize(bytesPerSec)}/s`;
}

/** Detect a coarse file kind from File metadata. */
export function detectType(file: { name: string; type?: string }): FileKind {
  const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
  const mime = file.type ?? "";
  if (mime.startsWith("image/") || ["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "avif", "heic"].includes(ext)) {
    return "image";
  }
  if (mime.startsWith("video/") || ["mp4", "mkv", "avi", "mov", "webm", "m4v"].includes(ext)) {
    return "video";
  }
  if (["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "md", "rtf", "odt"].includes(ext)) {
    return "document";
  }
  if (ext === "apk") return "apk";
  return "other";
}

export const typeIcons: Record<FileKind, LucideIcon> = {
  image: Image,
  video: Video,
  document: FileText,
  apk: Package,
  other: File,
};

export const typeColors: Record<FileKind, string> = {
  image: "bg-primary/10 text-primary",
  video: "bg-accent/10 text-accent",
  document: "bg-connect/10 text-connect",
  apk: "bg-destructive/10 text-destructive",
  other: "bg-muted text-muted-foreground",
};

/** Compute SHA-256 hash of a Blob/File and return its hex string. */
export async function sha256Hex(blob: Blob): Promise<string> {
  const buf = await blob.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", buf);
  const bytes = new Uint8Array(digest);
  let out = "";
  for (let i = 0; i < bytes.length; i++) {
    out += bytes[i].toString(16).padStart(2, "0");
  }
  return out;
}
