/**
 * Tiny error reporter — posts to Sentry's `store` endpoint when
 * VITE_SENTRY_DSN is configured. No-op otherwise. Avoids the heavy
 * @sentry/browser bundle for what we actually need.
 *
 * DSN format: https://<publicKey>@<host>/<projectId>
 */

interface ParsedDsn {
  endpoint: string;
  publicKey: string;
}

function parseDsn(dsn: string): ParsedDsn | null {
  try {
    const u = new URL(dsn);
    const publicKey = u.username;
    const projectId = u.pathname.replace(/^\//, "");
    if (!publicKey || !projectId) return null;
    return {
      publicKey,
      endpoint: `${u.protocol}//${u.host}/api/${projectId}/store/`,
    };
  } catch {
    return null;
  }
}

const dsn = import.meta.env.VITE_SENTRY_DSN as string | undefined;
const parsed = dsn ? parseDsn(dsn) : null;

let initialized = false;
const release = (import.meta.env.VITE_APP_VERSION as string | undefined) ?? "dev";
const environment = import.meta.env.MODE;

export function initReporter() {
  if (initialized || !parsed) return;
  initialized = true;
  window.addEventListener("error", (e) => {
    reportError(e.error ?? e.message, { source: "window.error" });
  });
  window.addEventListener("unhandledrejection", (e) => {
    reportError(e.reason, { source: "unhandledrejection" });
  });
}

export function reportError(err: unknown, ctx?: Record<string, unknown>) {
  if (!parsed) {
    if (import.meta.env.DEV) console.warn("[reporter] no DSN, skipping", err, ctx);
    return;
  }
  try {
    const e = err instanceof Error ? err : new Error(String(err));
    const payload = {
      event_id: crypto.randomUUID().replace(/-/g, ""),
      timestamp: Date.now() / 1000,
      platform: "javascript",
      level: "error",
      release,
      environment,
      exception: {
        values: [{ type: e.name, value: e.message, stacktrace: { frames: [] } }],
      },
      extra: { stack: e.stack, ...ctx },
    };
    const auth = [
      "Sentry sentry_version=7",
      `sentry_client=sharedrop-lite/1.0`,
      `sentry_key=${parsed.publicKey}`,
    ].join(", ");
    void fetch(parsed.endpoint, {
      method: "POST",
      keepalive: true,
      headers: {
        "Content-Type": "application/json",
        "X-Sentry-Auth": auth,
      },
      body: JSON.stringify(payload),
    }).catch(() => { /* swallow */ });
  } catch { /* never throw from reporter */ }
}
