/**
 * Privacy-friendly Plausible loader. Activated only when
 * VITE_PLAUSIBLE_DOMAIN is set. No cookies, no PII.
 */

const domain = import.meta.env.VITE_PLAUSIBLE_DOMAIN as string | undefined;
const apiHost =
  (import.meta.env.VITE_PLAUSIBLE_HOST as string | undefined) ??
  "https://plausible.io";

let injected = false;

export function initAnalytics() {
  if (injected || !domain || typeof document === "undefined") return;
  injected = true;
  const s = document.createElement("script");
  s.defer = true;
  s.setAttribute("data-domain", domain);
  s.src = `${apiHost}/js/script.js`;
  document.head.appendChild(s);
}

type Plausible = (event: string, opts?: { props?: Record<string, string | number | boolean> }) => void;

export function trackEvent(event: string, props?: Record<string, string | number | boolean>) {
  if (!domain) return;
  const w = window as unknown as { plausible?: Plausible };
  try { w.plausible?.(event, props ? { props } : undefined); } catch { /* ignore */ }
}
