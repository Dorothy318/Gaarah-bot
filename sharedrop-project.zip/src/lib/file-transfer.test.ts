import { describe, it, expect, vi } from "vitest";
import {
  sendFile,
  createReceiver,
  CHUNK_SIZE,
  type DataChannelLike,
} from "@/lib/file-transfer";

/** Minimal in-memory data channel that loops sends straight back to a handler. */
function makeMockChannel(onMessage: (data: string | ArrayBuffer) => void): DataChannelLike {
  const listeners = new Map<string, Set<() => void>>();
  return {
    readyState: "open",
    bufferedAmount: 0,
    bufferedAmountLowThreshold: 0,
    send(data) {
      // Normalise to string or ArrayBuffer.
      if (typeof data === "string") onMessage(data);
      else if (data instanceof ArrayBuffer) onMessage(data);
      else if (ArrayBuffer.isView(data)) {
        const copy = new Uint8Array(data.byteLength);
        copy.set(new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
        onMessage(copy.buffer);
      }
    },
    addEventListener(type, fn) {
      if (!listeners.has(type)) listeners.set(type, new Set());
      listeners.get(type)!.add(fn);
    },
    removeEventListener(type, fn) {
      listeners.get(type)?.delete(fn);
    },
  } as DataChannelLike;
}

describe("file-transfer roundtrip", () => {
  it("sends a small file and verifies integrity end to end", async () => {
    const onFile = vi.fn();
    const onError = vi.fn();
    const recv = createReceiver({ onFile, onError });
    const dc = makeMockChannel((data) => recv.handle(data));

    const blob = new Blob(["hello world"], { type: "text/plain" });
    const file = new File([blob], "hello.txt", { type: "text/plain" });

    const header = await sendFile(dc, file, { chunkSize: 4 });

    // Wait for the receiver's async finalize() (sha256 hashing).
    await vi.waitFor(() => expect(onFile).toHaveBeenCalledOnce(), { timeout: 1000 });

    expect(header.name).toBe("hello.txt");
    expect(onError).not.toHaveBeenCalled();
    expect(onFile).toHaveBeenCalledOnce();
    const received = onFile.mock.calls[0][0];
    expect(received.integrityOk).toBe(true);
    expect(await received.blob.text()).toBe("hello world");
  });

  it("emits progress callbacks", async () => {
    const recv = createReceiver();
    const dc = makeMockChannel((d) => recv.handle(d));
    const file = new File([new Uint8Array(CHUNK_SIZE * 2 + 10)], "big.bin");
    const progress = vi.fn();
    await sendFile(dc, file, { onProgress: progress });
    expect(progress).toHaveBeenCalled();
    const last = progress.mock.calls[progress.mock.calls.length - 1][0];
    expect(last.percent).toBe(100);
  });

  it("rejects when channel is not open", async () => {
    const dc = makeMockChannel(() => {});
    (dc as { readyState: string }).readyState = "closed";
    const file = new File(["x"], "x.txt");
    await expect(sendFile(dc, file)).rejects.toThrow(/not open/);
  });
});
