/**
 * Thumbnail generation for selected files.
 * - Images: object URL (cheap, browser handles decoding).
 * - Videos: capture the first frame (~0.1s) into a JPEG data URL.
 * Returns null when not generable; callers should fall back to type icon.
 */

export async function generateVideoThumbnail(file: File, maxSize = 160): Promise<string | null> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.playsInline = true;
    video.src = url;

    const cleanup = () => {
      URL.revokeObjectURL(url);
      video.removeAttribute("src");
      video.load();
    };

    const fail = () => { cleanup(); resolve(null); };
    const timer = setTimeout(fail, 4000);

    video.onloadeddata = () => {
      try { video.currentTime = Math.min(0.1, (video.duration || 1) / 2); } catch { fail(); }
    };
    video.onseeked = () => {
      try {
        const ratio = video.videoWidth / video.videoHeight || 1;
        const w = ratio >= 1 ? maxSize : Math.round(maxSize * ratio);
        const h = ratio >= 1 ? Math.round(maxSize / ratio) : maxSize;
        const canvas = document.createElement("canvas");
        canvas.width = w; canvas.height = h;
        const ctx = canvas.getContext("2d");
        if (!ctx) { fail(); return; }
        ctx.drawImage(video, 0, 0, w, h);
        const data = canvas.toDataURL("image/jpeg", 0.7);
        clearTimeout(timer);
        cleanup();
        resolve(data);
      } catch {
        fail();
      }
    };
    video.onerror = fail;
  });
}
