import { describe, it, expect } from "vitest";
import { formatSize, formatSpeed, detectType, sha256Hex } from "@/lib/file-utils";

describe("formatSize", () => {
  it("formats bytes", () => {
    expect(formatSize(0)).toBe("0 B");
    expect(formatSize(512)).toBe("512 B");
  });
  it("formats KB / MB / GB", () => {
    expect(formatSize(2048)).toBe("2.0 KB");
    expect(formatSize(5 * 1024 * 1024)).toBe("5.0 MB");
    expect(formatSize(2 * 1024 * 1024 * 1024)).toBe("2.00 GB");
  });
  it("guards against bad input", () => {
    expect(formatSize(NaN)).toBe("—");
    expect(formatSize(-1)).toBe("—");
  });
});

describe("formatSpeed", () => {
  it("appends /s", () => {
    expect(formatSpeed(2 * 1024 * 1024)).toBe("2.0 MB/s");
  });
  it("rejects non-positive", () => {
    expect(formatSpeed(0)).toBe("—");
    expect(formatSpeed(-5)).toBe("—");
  });
});

describe("detectType", () => {
  it("detects images by mime or ext", () => {
    expect(detectType({ name: "a.png", type: "image/png" })).toBe("image");
    expect(detectType({ name: "a.HEIC", type: "" })).toBe("image");
  });
  it("detects video, document, apk, other", () => {
    expect(detectType({ name: "v.mp4", type: "video/mp4" })).toBe("video");
    expect(detectType({ name: "doc.pdf", type: "" })).toBe("document");
    expect(detectType({ name: "app.apk", type: "" })).toBe("apk");
    expect(detectType({ name: "weird.xyz", type: "" })).toBe("other");
  });
});

describe("sha256Hex", () => {
  it("hashes empty blob to known constant", async () => {
    const hash = await sha256Hex(new Blob([]));
    expect(hash).toBe(
      "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    );
  });
  it("is deterministic", async () => {
    const a = await sha256Hex(new Blob(["hello"]));
    const b = await sha256Hex(new Blob(["hello"]));
    expect(a).toBe(b);
  });
});
