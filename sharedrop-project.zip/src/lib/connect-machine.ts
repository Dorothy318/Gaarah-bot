/**
 * Pure finite state machine for ConnectScreen.
 *
 * Centralizes all transitions between the three connection methods (QR / Wi-Fi /
 * Bluetooth) and their substates (idle/scanning/devices/connecting/connected/failed).
 *
 * Kept framework-free so it can be unit-tested without React.
 */

export type ConnectMethod = "qr" | "wifi" | "bt";

export type ConnectStatus =
  | { kind: "idle" }
  | { kind: "method-selected"; method: ConnectMethod }
  | { kind: "scanning"; method: "wifi" | "bt" }
  | { kind: "devices-found"; method: "wifi" | "bt"; count: number }
  | { kind: "connecting"; method: ConnectMethod; deviceId?: string }
  | { kind: "connected"; method: ConnectMethod; deviceId?: string }
  | { kind: "failed"; method: ConnectMethod; reason: string };

export type ConnectEvent =
  | { type: "SELECT_METHOD"; method: ConnectMethod }
  | { type: "RESET" }
  | { type: "START_SCAN"; method: "wifi" | "bt" }
  | { type: "SCAN_RESULT"; method: "wifi" | "bt"; count: number }
  | { type: "SCAN_FAILED"; method: "wifi" | "bt"; reason: string }
  | { type: "CONNECT_DEVICE"; method: ConnectMethod; deviceId?: string }
  | { type: "CONNECTED"; method: ConnectMethod; deviceId?: string }
  | { type: "DISCONNECT" }
  | { type: "FAIL"; method: ConnectMethod; reason: string };

export const initialConnectStatus: ConnectStatus = { kind: "idle" };

/** Pure reducer — no side effects, fully deterministic. */
export function connectReducer(state: ConnectStatus, event: ConnectEvent): ConnectStatus {
  switch (event.type) {
    case "RESET":
      return { kind: "idle" };

    case "SELECT_METHOD":
      return { kind: "method-selected", method: event.method };

    case "START_SCAN":
      if (event.method !== "wifi" && event.method !== "bt") return state;
      return { kind: "scanning", method: event.method };

    case "SCAN_RESULT":
      return { kind: "devices-found", method: event.method, count: event.count };

    case "SCAN_FAILED":
      return { kind: "failed", method: event.method, reason: event.reason };

    case "CONNECT_DEVICE":
      return { kind: "connecting", method: event.method, deviceId: event.deviceId };

    case "CONNECTED":
      return { kind: "connected", method: event.method, deviceId: event.deviceId };

    case "DISCONNECT":
      if (state.kind === "connected" || state.kind === "connecting") {
        return { kind: "method-selected", method: state.method };
      }
      return state;

    case "FAIL":
      return { kind: "failed", method: event.method, reason: event.reason };

    default:
      return state;
  }
}

/** Convenience helper to display a localized status label. */
export function describeConnectStatus(s: ConnectStatus): string {
  switch (s.kind) {
    case "idle": return "Inactif";
    case "method-selected": return "Méthode sélectionnée";
    case "scanning": return "Recherche d'appareils en cours";
    case "devices-found": return `${s.count} appareil(s) trouvé(s)`;
    case "connecting": return "Connexion en cours";
    case "connected": return "Connecté";
    case "failed": return `Échec : ${s.reason}`;
  }
}
