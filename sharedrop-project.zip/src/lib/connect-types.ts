/** Shared types used by the Connect screen and its panels. */

export interface DiscoveredDevice {
  id: string;
  name: string;
  type: "phone" | "pc";
  signal: string;
  ip?: string;
}

export interface ConnectionHistoryEntry {
  id: string;
  name: string;
  type: "phone" | "pc";
  method: "wifi" | "bt" | "qr";
  time: string;
  ip?: string;
}

export const HISTORY_STORAGE_KEY = "sharedrop_connection_history";

export function loadHistory(): ConnectionHistoryEntry[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as ConnectionHistoryEntry[]) : [];
  } catch {
    return [];
  }
}

export function saveHistoryEntry(
  device: DiscoveredDevice,
  method: ConnectionHistoryEntry["method"],
): ConnectionHistoryEntry[] {
  const history = loadHistory();
  const entry: ConnectionHistoryEntry = {
    id: crypto.randomUUID(),
    name: device.name,
    type: device.type,
    method,
    time: new Date().toLocaleString("fr-FR", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }),
    ip: device.ip,
  };
  const updated = [entry, ...history.filter((h) => h.name !== device.name)].slice(0, 10);
  localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
  return updated;
}

export function clearHistoryStorage() {
  localStorage.removeItem(HISTORY_STORAGE_KEY);
}

/** Best-effort detection of the network conditions for the Wi-Fi panel. */
export function getNetworkInfo(): { type: string; downlink: number; effectiveType: string } | null {
  const nav = navigator as Navigator & {
    connection?: { type?: string; downlink?: number; effectiveType?: string };
    mozConnection?: { type?: string; downlink?: number; effectiveType?: string };
    webkitConnection?: { type?: string; downlink?: number; effectiveType?: string };
  };
  const conn = nav.connection ?? nav.mozConnection ?? nav.webkitConnection;
  if (!conn) return null;
  return {
    type: conn.type ?? "unknown",
    downlink: conn.downlink ?? 0,
    effectiveType: conn.effectiveType ?? "4g",
  };
}
