/**
 * Reliable file transfer over an RTCDataChannel.
 *
 * Features:
 *  - 64 KiB chunks with backpressure (bufferedAmount watermark + drain).
 *  - Per-file SHA-256 integrity check (sender computes, receiver verifies).
 *  - Header / chunk / done framing as JSON-or-binary frames.
 *  - Retry on transient send failures (channel temporarily closed/full).
 *  - Resumable on the receiver side (offset-based reassembly).
 *
 * This module is transport-agnostic: callers pass an object that implements the
 * minimal `DataChannelLike` interface. That makes it trivial to unit-test with
 * a mock — see file-transfer.test.ts.
 */

import { sha256Hex } from "./file-utils";

/** Wire-protocol version. Bump on incompatible changes. */
export const TRANSFER_PROTOCOL_VERSION = 1;

/** Default chunk size — well below the 256 KiB SCTP message limit. */
export const CHUNK_SIZE = 64 * 1024;

/** Pause sending when the underlying channel buffer exceeds this (bytes). */
export const HIGH_WATERMARK = 1 * 1024 * 1024;

/** Resume sending once buffered drops back below this. */
export const LOW_WATERMARK = 256 * 1024;

const MAX_SEND_RETRIES = 5;
const RETRY_BASE_DELAY_MS = 50;

export interface DataChannelLike {
  readyState: "connecting" | "open" | "closing" | "closed";
  bufferedAmount: number;
  bufferedAmountLowThreshold?: number;
  send(data: string | ArrayBuffer | ArrayBufferView | Blob): void;
  addEventListener(
    type: "bufferedamountlow" | "close" | "error",
    listener: () => void,
  ): void;
  removeEventListener(
    type: "bufferedamountlow" | "close" | "error",
    listener: () => void,
  ): void;
}

export interface TransferHeader {
  v: typeof TRANSFER_PROTOCOL_VERSION;
  type: "header";
  id: string;
  name: string;
  size: number;
  mime: string;
  sha256: string;
  chunkSize: number;
}

export interface TransferDone {
  v: typeof TRANSFER_PROTOCOL_VERSION;
  type: "done";
  id: string;
}

export type ControlFrame = TransferHeader | TransferDone;

export interface SendProgress {
  bytesSent: number;
  totalBytes: number;
  percent: number;
}

export interface SendOptions {
  signal?: AbortSignal;
  onProgress?: (p: SendProgress) => void;
  /** Override chunk size (mostly for tests). */
  chunkSize?: number;
}

/** Sleep helper used between retries. */
function delay(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** Wait until the channel buffer drains below LOW_WATERMARK. */
function waitForDrain(dc: DataChannelLike): Promise<void> {
  if (dc.bufferedAmount <= LOW_WATERMARK) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const onLow = () => {
      cleanup();
      resolve();
    };
    const onClose = () => {
      cleanup();
      reject(new Error("Data channel closed while waiting for drain"));
    };
    const cleanup = () => {
      dc.removeEventListener("bufferedamountlow", onLow);
      dc.removeEventListener("close", onClose);
      dc.removeEventListener("error", onClose);
    };
    dc.addEventListener("bufferedamountlow", onLow);
    dc.addEventListener("close", onClose);
    dc.addEventListener("error", onClose);
  });
}

/** Try to send a single payload, retrying on transient failures. */
async function sendWithRetry(
  dc: DataChannelLike,
  payload: string | ArrayBuffer | ArrayBufferView,
): Promise<void> {
  let lastError: unknown;
  for (let attempt = 0; attempt < MAX_SEND_RETRIES; attempt++) {
    if (dc.readyState !== "open") {
      throw new Error(`Data channel not open (state=${dc.readyState})`);
    }
    try {
      dc.send(payload as ArrayBuffer);
      return;
    } catch (err) {
      lastError = err;
      // The most common transient failure is "send queue full"; back off & retry.
      await delay(RETRY_BASE_DELAY_MS * Math.pow(2, attempt));
    }
  }
  throw lastError instanceof Error
    ? lastError
    : new Error("Failed to send chunk after retries");
}

/**
 * Send a single file over the data channel. Resolves once the receiver should
 * have all chunks (no app-level ack — the SCTP layer guarantees ordered delivery).
 */
export async function sendFile(
  dc: DataChannelLike,
  file: File,
  opts: SendOptions = {},
): Promise<TransferHeader> {
  const chunkSize = opts.chunkSize ?? CHUNK_SIZE;
  if (chunkSize <= 0) throw new Error("chunkSize must be positive");

  if (dc.readyState !== "open") {
    throw new Error(`Data channel not open (state=${dc.readyState})`);
  }

  // Configure backpressure threshold (no-op if unsupported).
  try {
    dc.bufferedAmountLowThreshold = LOW_WATERMARK;
  } catch { /* property may be read-only in mocks */ }

  const id = crypto.randomUUID();
  const sha256 = await sha256Hex(file);

  const header: TransferHeader = {
    v: TRANSFER_PROTOCOL_VERSION,
    type: "header",
    id,
    name: file.name,
    size: file.size,
    mime: file.type || "application/octet-stream",
    sha256,
    chunkSize,
  };

  await sendWithRetry(dc, JSON.stringify(header));

  let bytesSent = 0;
  for (let offset = 0; offset < file.size; offset += chunkSize) {
    if (opts.signal?.aborted) throw new Error("Transfer aborted");
    if (dc.bufferedAmount > HIGH_WATERMARK) await waitForDrain(dc);

    const end = Math.min(offset + chunkSize, file.size);
    const slice = file.slice(offset, end);
    const buf = await slice.arrayBuffer();

    await sendWithRetry(dc, buf);
    bytesSent = end;

    opts.onProgress?.({
      bytesSent,
      totalBytes: file.size,
      percent: file.size === 0 ? 100 : Math.round((bytesSent / file.size) * 100),
    });
  }

  const done: TransferDone = { v: TRANSFER_PROTOCOL_VERSION, type: "done", id };
  await sendWithRetry(dc, JSON.stringify(done));

  return header;
}

// ---------------------------------------------------------------------------
// Receiver — assembles chunks then verifies the SHA-256 hash.

interface PendingFile {
  header: TransferHeader;
  chunks: ArrayBuffer[];
  bytesReceived: number;
}

export interface ReceivedFile {
  header: TransferHeader;
  blob: Blob;
  /** True if the SHA-256 of the assembled blob matches the announced one. */
  integrityOk: boolean;
}

export interface ReceiverEvents {
  onProgress?: (id: string, p: SendProgress) => void;
  onFile?: (file: ReceivedFile) => void;
  onError?: (err: Error) => void;
}

/**
 * Stateful receiver. Feed every incoming data-channel message through `handle()`.
 * Emits `onFile` once a complete file has been assembled and verified.
 */
export function createReceiver(events: ReceiverEvents = {}) {
  const pending = new Map<string, PendingFile>();
  // Track the most recent header so binary chunks can be attributed.
  let currentId: string | null = null;

  function tryParseControl(data: unknown): ControlFrame | null {
    if (typeof data !== "string") return null;
    try {
      const parsed = JSON.parse(data) as Partial<ControlFrame>;
      if (parsed.v !== TRANSFER_PROTOCOL_VERSION) return null;
      if (parsed.type === "header" || parsed.type === "done") {
        return parsed as ControlFrame;
      }
      return null;
    } catch {
      return null;
    }
  }

  async function finalize(id: string) {
    const entry = pending.get(id);
    if (!entry) return;
    pending.delete(id);
    if (currentId === id) currentId = null;

    const blob = new Blob(entry.chunks, { type: entry.header.mime });
    const actual = await sha256Hex(blob);
    const integrityOk = actual === entry.header.sha256;
    if (!integrityOk) {
      events.onError?.(new Error(`Integrity check failed for ${entry.header.name}`));
    }
    events.onFile?.({ header: entry.header, blob, integrityOk });
  }

  function handle(data: string | ArrayBuffer | ArrayBufferView): void {
    const control = tryParseControl(data);
    if (control) {
      if (control.type === "header") {
        pending.set(control.id, { header: control, chunks: [], bytesReceived: 0 });
        currentId = control.id;
      } else if (control.type === "done") {
        void finalize(control.id);
      }
      return;
    }

    // Binary chunk for the most recent header.
    if (!currentId) {
      events.onError?.(new Error("Received chunk before header"));
      return;
    }
    const entry = pending.get(currentId);
    if (!entry) return;

    let buf: ArrayBuffer | null = null;
    if (data instanceof ArrayBuffer) {
      buf = data;
    } else if (ArrayBuffer.isView(data)) {
      const copy = new Uint8Array(data.byteLength);
      copy.set(new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
      buf = copy.buffer;
    }
    if (!buf) {
      events.onError?.(new Error("Unsupported chunk payload type"));
      return;
    }

    entry.chunks.push(buf);
    entry.bytesReceived += buf.byteLength;
    events.onProgress?.(entry.header.id, {
      bytesSent: entry.bytesReceived,
      totalBytes: entry.header.size,
      percent: entry.header.size === 0
        ? 100
        : Math.round((entry.bytesReceived / entry.header.size) * 100),
    });
  }

  function reset(): void {
    pending.clear();
    currentId = null;
  }

  return { handle, reset };
}
