import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  getDefaultIceServers,
  hasTurnConfigured,
  joinSignalingRoom,
  type SignalingClient,
  type SignalMessage,
  type SignalRole,
} from "@/lib/webrtc-signaling";
import { reportError } from "@/lib/reporter";

export type PeerStatus =
  | "idle"
  | "joining"
  | "waiting"
  | "connecting"
  | "connected"
  | "disconnected"
  | "failed";

interface UseWebRTCPeerOptions {
  onChannelOpen?: (channel: RTCDataChannel) => void;
  onMessage?: (data: ArrayBuffer | string) => void;
  /** Require a logged-in user before joining the signaling room. */
  requireSession?: boolean;
}

/**
 * High-level WebRTC peer hook backed by hardened Supabase Realtime signaling.
 *
 *   const peer = useWebRTCPeer();
 *   await peer.connect("ROOMCODE", "TOKEN", "host" | "guest");
 *   peer.send("hello");
 */
export function useWebRTCPeer(opts: UseWebRTCPeerOptions = {}) {
  const [status, setStatus] = useState<PeerStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const [remotePeerId, setRemotePeerId] = useState<string | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const dcRef = useRef<RTCDataChannel | null>(null);
  const signalRef = useRef<SignalingClient | null>(null);
  const roleRef = useRef<SignalRole | null>(null);
  const remoteIdRef = useRef<string | null>(null);
  const optsRef = useRef(opts);
  optsRef.current = opts;

  const cleanup = useCallback(async () => {
    try { dcRef.current?.close(); } catch { /* ignore */ }
    try { pcRef.current?.close(); } catch { /* ignore */ }
    try { await signalRef.current?.close(); } catch { /* ignore */ }
    dcRef.current = null;
    pcRef.current = null;
    signalRef.current = null;
    remoteIdRef.current = null;
    setRemotePeerId(null);
  }, []);

  useEffect(() => () => { void cleanup(); }, [cleanup]);

  const attachChannel = useCallback((channel: RTCDataChannel) => {
    dcRef.current = channel;
    channel.binaryType = "arraybuffer";
    channel.onopen = () => {
      setStatus("connected");
      optsRef.current.onChannelOpen?.(channel);
    };
    channel.onclose = () => setStatus("disconnected");
    channel.onerror = () => setStatus("failed");
    channel.onmessage = (e) => optsRef.current.onMessage?.(e.data);
  }, []);

  const handleSignal = useCallback(async (msg: SignalMessage) => {
    const pc = pcRef.current;
    const sig = signalRef.current;
    if (!pc || !sig) return;

    // Defense in depth: re-check role pairing (guard against bugs).
    if (msg.fromRole === sig.role) return;

    switch (msg.type) {
      case "hello": {
        if (sig.role === "host" && !remoteIdRef.current) {
          remoteIdRef.current = msg.from;
          setRemotePeerId(msg.from);
          setStatus("connecting");
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          await sig.send({ type: "offer", to: msg.from, sdp: offer });
        } else if (sig.role === "guest" && !remoteIdRef.current) {
          remoteIdRef.current = msg.from;
          setRemotePeerId(msg.from);
          setStatus("connecting");
        }
        break;
      }
      case "offer": {
        if (msg.to !== sig.peerId) return;
        if (sig.role !== "guest") return; // only guests answer offers
        // Bind the remote peer if not already
        if (!remoteIdRef.current) remoteIdRef.current = msg.from;
        else if (remoteIdRef.current !== msg.from) return; // ignore second peer
        setRemotePeerId(msg.from);
        setStatus("connecting");
        await pc.setRemoteDescription(msg.sdp);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        await sig.send({ type: "answer", to: msg.from, sdp: answer });
        break;
      }
      case "answer": {
        if (msg.to !== sig.peerId) return;
        if (sig.role !== "host") return; // only hosts consume answers
        if (remoteIdRef.current && remoteIdRef.current !== msg.from) return;
        await pc.setRemoteDescription(msg.sdp);
        break;
      }
      case "ice": {
        if (msg.to !== sig.peerId) return;
        if (!remoteIdRef.current || remoteIdRef.current !== msg.from) return;
        try {
          await pc.addIceCandidate(msg.candidate);
        } catch (err) {
          console.warn("Failed to add ICE candidate", err);
        }
        break;
      }
      case "bye": {
        if (msg.from === remoteIdRef.current) setStatus("disconnected");
        break;
      }
    }
  }, []);

  const connect = useCallback(
    async (roomCode: string, token: string, role: SignalRole) => {
      await cleanup();
      setError(null);
      setStatus("joining");
      roleRef.current = role;

      try {
        const pc = new RTCPeerConnection({ iceServers: getDefaultIceServers() });
        pcRef.current = pc;

        pc.onconnectionstatechange = () => {
          const s = pc.connectionState;
          if (s === "connected") setStatus("connected");
          else if (s === "disconnected") setStatus("disconnected");
          else if (s === "failed") setStatus("failed");
        };

        pc.ondatachannel = (e) => attachChannel(e.channel);

        const sig = await joinSignalingRoom(roomCode, token, role, {
          requireSession: optsRef.current.requireSession,
        });
        signalRef.current = sig;

        pc.onicecandidate = (e) => {
          if (e.candidate && remoteIdRef.current && signalRef.current) {
            void signalRef.current.send({
              type: "ice",
              to: remoteIdRef.current,
              candidate: e.candidate.toJSON(),
            });
          }
        };

        sig.onMessage((m) => { void handleSignal(m); });

        if (role === "host") {
          const dc = pc.createDataChannel("files", { ordered: true });
          attachChannel(dc);
        }

        setStatus("waiting");
      } catch (err) {
        const message = err instanceof Error ? err.message : "Unknown error";
        setError(message);
        setStatus("failed");
        toast.error("Échec de connexion", { description: message });
        reportError(err, { phase: "connect", role });
        await cleanup();
      }
    },
    [attachChannel, cleanup, handleSignal],
  );

  const send = useCallback((data: string | ArrayBuffer | Blob) => {
    const dc = dcRef.current;
    if (!dc || dc.readyState !== "open") return false;
    if (data instanceof Blob) {
      void data.arrayBuffer().then((buf) => dc.send(buf));
    } else if (typeof data === "string") {
      dc.send(data);
    } else {
      dc.send(data);
    }
    return true;
  }, []);

  const disconnect = useCallback(async () => {
    await cleanup();
    setStatus("idle");
  }, [cleanup]);

  return { status, error, remotePeerId, connect, send, disconnect };
}
