import { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import AppShell from "@/components/AppShell";
import AnimatedRoutes from "@/components/AnimatedRoutes";
import OnboardingScreen from "@/pages/OnboardingScreen";
import { AuthProvider } from "@/contexts/AuthContext";
import { TransferSessionProvider } from "@/contexts/TransferSession";

const queryClient = new QueryClient();

const App = () => {
  const [onboarded, setOnboarded] = useState(() => {
    return localStorage.getItem("sharedrop_onboarded") === "true";
  });

  const handleOnboardingComplete = () => {
    localStorage.setItem("sharedrop_onboarded", "true");
    setOnboarded(true);
  };

  if (!onboarded) {
    return <OnboardingScreen onComplete={handleOnboardingComplete} />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TransferSessionProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <AppShell>
                <AnimatedRoutes />
              </AppShell>
            </BrowserRouter>
          </TooltipProvider>
        </TransferSessionProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
