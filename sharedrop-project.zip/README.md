# ShareDrop

PWA de partage de fichiers en pair-à-pair (WebRTC), avec signaling chiffré
via Supabase Realtime Broadcast. Locale FR, mobile-first.

## Stack

- React 18 + Vite 5 + TypeScript
- Tailwind + shadcn/ui (tokens HSL, design system dans `src/index.css`)
- Framer Motion, sonner (toasts)
- Lovable Cloud (Supabase) — auth + Realtime
- Vitest + Playwright

## Démarrage

```bash
bun install
bun run dev          # serveur Vite
bun run test         # tests Vitest
bun run typecheck    # tsc --noEmit
bun run verify       # tsc + eslint --max-warnings 0 + vitest
ANALYZE=true bun run build   # bundle visualizer
```

## Variables d'environnement

Toutes optionnelles (sauf celles préfixées `VITE_SUPABASE_*` qui sont
gérées par Lovable Cloud).

| Variable | Rôle |
|---|---|
| `VITE_TURN_URLS` | URLs TURN séparées par des virgules (`turn:host:3478,turns:host:5349`). Sans cette var, l'app fonctionne en STUN seul et affiche un avertissement. |
| `VITE_TURN_USERNAME` | Identifiant TURN |
| `VITE_TURN_CREDENTIAL` | Credential TURN |
| `VITE_SENTRY_DSN` | DSN Sentry (`https://<key>@<host>/<project>`). Active le reporter d'erreurs léger. |
| `VITE_PLAUSIBLE_DOMAIN` | Domaine Plausible (ex. `sharedrop.app`). Charge le script analytics sans cookies. |
| `VITE_PLAUSIBLE_HOST` | Override du host Plausible (défaut `https://plausible.io`) |
| `VITE_APP_VERSION` | Tag de release envoyé à Sentry |

## TURN — fournisseurs recommandés

- **Metered.ca** : 50 GB/mois gratuits, setup en 2 min.
- **Twilio Network Traversal** : robuste, payant.
- **coturn** auto-hébergé : contrôle total.

Sans TURN, ~10–20 % des connexions échouent (NATs symétriques, pare-feux
d'entreprise). Le badge "Mode STUN seul" apparaît sur ConnectScreen tant
que `VITE_TURN_URLS` n'est pas configuré.

## Architecture

- `src/lib/webrtc-signaling.ts` — signaling HMAC-SHA256, replay protection
  persistante, rate-limit token-bucket (20 burst / 10 msg·s⁻¹).
- `src/lib/file-transfer.ts` — transfert chunké 64 KiB, backpressure,
  retry exponentiel, intégrité SHA-256.
- `src/lib/connect-machine.ts` — réducteur pur pour ConnectScreen.
- `src/components/connect/` — sous-panneaux (QR, Wi-Fi, Bluetooth, Historique).
- `src/lib/reporter.ts` — reporter Sentry-lite (pas de dépendance lourde).
- `src/lib/analytics.ts` — chargeur Plausible conditionnel.

## Tests

26 tests unitaires couvrent : signaling (codes/tokens/invites), utilitaires
fichiers, machine d'état Connect, transfert chunké.

```bash
bun run test
```

## Pre-commit (optionnel, côté repo Git)

```bash
# .husky/pre-commit ou lefthook.yml
bun run verify
```
