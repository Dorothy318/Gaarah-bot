import { test, expect } from "../playwright-fixture";

/**
 * Smoke test: onboarding → home → connect screen renders.
 * WebRTC end-to-end (two peers) isn't feasible headlessly here,
 * so we validate the primary UI shell and navigation.
 */
test("onboarding to connect screen", async ({ page }) => {
  await page.addInitScript(() => {
    localStorage.setItem("sharedrop_onboarded", "true");
  });

  await page.goto("/");
  await expect(page).toHaveTitle(/ShareDrop|Lovable/i);

  // Navigate to connect screen via bottom nav (aria-label "Connecter").
  const connect = page.getByRole("link", { name: /connect/i }).first();
  if (await connect.isVisible().catch(() => false)) {
    await connect.click();
  } else {
    await page.goto("/connect");
  }

  await expect(page.locator("body")).toBeVisible();
});
